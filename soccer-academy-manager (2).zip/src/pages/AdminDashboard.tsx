import React, { useState, useEffect, useRef } from 'react';
import { Search, Filter, UserPlus, Users, Coins, AlertCircle, LogOut, GraduationCap, TrendingUp, Settings as SettingsIcon, Camera, Shield, Check, X, Calendar, CreditCard, Menu, Upload, Download, UserMinus, UserCheck, Phone, MapPin, ArrowLeft, Clock, History, ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';

const chartData = [
  { name: 'Ene', ingresos: 1800, alumnosActivos: 120 },
  { name: 'Feb', ingresos: 2100, alumnosActivos: 132 },
  { name: 'Mar', ingresos: 2450, alumnosActivos: 142 },
  { name: 'Abr', ingresos: 2300, alumnosActivos: 138 },
  { name: 'May', ingresos: 2700, alumnosActivos: 150 },
  { name: 'Jun', ingresos: 3100, alumnosActivos: 165 },
];

const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;
const currentMonthStr = `${currentYear}-${currentMonth.toString().padStart(2, '0')}`;

const getAcademyMonths = () => {
  const months = [];
  const date = new Date();
  // Show 6 months back and 6 months forward
  date.setMonth(date.getMonth() - 6);
  
  for (let i = 0; i < 13; i++) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const id = `${year}-${month.toString().padStart(2, '0')}`;
    const name = date.toLocaleString('es-ES', { month: 'long' });
    const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);
    months.push({ id, name: `${capitalizedName} ${year}` });
    date.setMonth(date.getMonth() + 1);
  }
  return months;
};

const ACADEMY_MONTHS = getAcademyMonths();

// Safe localStorage access
const getSafeStorage = (key: string, defaultValue: string) => {
  try {
    return localStorage.getItem(key) || defaultValue;
  } catch (e) {
    console.error('Error accessing localStorage:', e);
    return defaultValue;
  }
};

const setSafeStorage = (key: string, value: string) => {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.error('Error setting localStorage:', e);
  }
};

export default function AdminDashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [showEvaluationModal, setShowEvaluationModal] = useState(false);
  const [academyName, setAcademyName] = useState(getSafeStorage('academyName', 'Sportly Academy'));
  const [logo, setLogo] = useState(getSafeStorage('logo', '⚽'));
  const [sidebarBanner, setSidebarBanner] = useState(getSafeStorage('sidebarBanner', 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2000&auto=format&fit=crop'));
  const [selectedMonth, setSelectedMonth] = useState(currentMonthStr);
  const [schedules, setSchedules] = useState([
    { day: 'Lunes', time: '17:00 - 18:30', category: 'Todas' },
    { day: 'Miércoles', time: '17:00 - 18:30', category: 'Todas' },
    { day: 'Viernes', time: '17:00 - 18:30', category: 'Todas' },
  ]);
  
  const [studentsData, setStudentsData] = useState([
    { 
      id: 1,
      name: 'Mateo García', 
      dni: '48.123.456', 
      category: '2012',
      status: 'active',
      birthDate: '15/03/2012',
      phone: '+54 9 11 1234-5678',
      email: 'mateo.garcia@email.com',
      photo: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=200&auto=format&fit=crop',
      parents: [
        { name: 'Roberto García', role: 'Padre', phone: '+54 9 11 8765-4321', email: 'roberto.g@email.com' },
        { name: 'Laura Martínez', role: 'Madre', phone: '+54 9 11 5544-3322', email: 'laura.m@email.com' }
      ],
      payments: [currentMonthStr],
      attendance: [1, 3, 5, 8, 10, 12, 15],
      biometrics: { weight: 42, height: 1.55, imc: 17.5 },
      evaluations: [
        { 
          date: '2026-01-15', 
          technical: 70, physical: 65, tactical: 60, psychological: 80, 
          weight: 41, height: 1.54,
          notes: 'Buen inicio de año, enfocado en fundamentos.' 
        },
        { 
          date: '2026-02-15', 
          technical: 75, physical: 70, tactical: 65, psychological: 85, 
          weight: 41.5, height: 1.54,
          notes: 'Mejora notable en resistencia.' 
        },
        { 
          date: '2026-03-15', 
          technical: 85, physical: 70, tactical: 75, psychological: 90, 
          weight: 42, height: 1.55,
          notes: 'Excelente progreso técnico este mes.' 
        },
      ],
      performance: [
        { name: 'Ene', valor: 68 },
        { name: 'Feb', valor: 72 },
        { name: 'Mar', valor: 80 },
      ],
      skills: [
        { subject: 'Técnico', A: 85, fullMark: 100 },
        { subject: 'Físico', A: 70, fullMark: 100 },
        { subject: 'Táctico', A: 75, fullMark: 100 },
        { subject: 'Psicológico', A: 90, fullMark: 100 },
        { subject: 'Asistencia', A: 85, fullMark: 100 },
        { subject: 'Biométrico', A: 65, fullMark: 100 },
      ]
    },
    { 
      id: 2,
      name: 'Lucía Torres', 
      dni: '50.112.334', 
      category: '2014',
      status: 'active',
      birthDate: '22/07/2014',
      phone: '+54 9 11 9988-7766',
      email: 'lucia.t@email.com',
      photo: 'https://images.unsplash.com/photo-1517677129300-07b130802f46?q=80&w=200&auto=format&fit=crop',
      parents: [
        { name: 'Marcos Torres', role: 'Padre', phone: '+54 9 11 1122-3344', email: 'marcos.t@email.com' }
      ],
      payments: [],
      attendance: [2, 4, 6],
      biometrics: { weight: 32, height: 1.38, imc: 16.8 },
      evaluations: [
        { 
          date: '2026-02-10', 
          technical: 60, physical: 75, tactical: 50, psychological: 60, 
          weight: 31.5, height: 1.37,
          notes: 'Mucha energía, falta pulir técnica.' 
        },
        { 
          date: '2026-03-10', 
          technical: 65, physical: 80, tactical: 55, psychological: 70, 
          weight: 32, height: 1.38,
          notes: 'Mejorando la atención en clase.' 
        },
      ],
      performance: [
        { name: 'Feb', valor: 61 },
        { name: 'Mar', valor: 67 },
      ],
      skills: [
        { subject: 'Técnico', A: 65, fullMark: 100 },
        { subject: 'Físico', A: 80, fullMark: 100 },
        { subject: 'Táctico', A: 55, fullMark: 100 },
        { subject: 'Psicológico', A: 70, fullMark: 100 },
        { subject: 'Asistencia', A: 60, fullMark: 100 },
        { subject: 'Biométrico', A: 60, fullMark: 100 },
      ]
    },
    { 
      id: 3,
      name: 'Julián Pérez', 
      dni: '45.998.112', 
      category: '2011',
      status: 'inactive',
      birthDate: '10/01/2011',
      phone: '+54 9 11 2233-4455',
      email: 'julian.p@email.com',
      parents: [
        { name: 'Elena Pérez', role: 'Madre', phone: '+54 9 11 6677-8899', email: 'elena.p@email.com' }
      ],
      payments: []
    }
  ]);

  const getStudentMonthlyStatus = (student: any, month: string) => {
    if (student.status === 'inactive') return 'inactive';
    if (student.payments.includes(month)) return 'active';
    return 'pending';
  };

  const activeStudentsCount = studentsData.filter(s => getStudentMonthlyStatus(s, selectedMonth) === 'active').length;
  const pendingPaymentsCount = studentsData.filter(s => getStudentMonthlyStatus(s, selectedMonth) === 'pending').length;
  const monthlyIncome = activeStudentsCount * 45; // Assuming S/ 45 per student for now

  // Login Customization States
  const [loginLogo, setLoginLogo] = useState(getSafeStorage('loginLogo', '⚽'));
  const [loginName, setLoginName] = useState(getSafeStorage('loginName', 'Sportly'));
  const [loginBgImage, setLoginBgImage] = useState(getSafeStorage('loginBgImage', 'https://images.unsplash.com/photo-1502691876148-a84978e59af8?q=80&w=2070&auto=format&fit=crop'));
  const [loginBgPresets, setLoginBgPresets] = useState(() => {
    const saved = localStorage.getItem('loginBgPresets');
    return saved ? JSON.parse(saved) : [
      'https://images.unsplash.com/photo-1502691876148-a84978e59af8?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1533134486753-c833f0ed4866?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2070&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1510511459019-5dee99c48db8?q=80&w=2070&auto=format&fit=crop'
    ];
  });

  useEffect(() => {
    setSafeStorage('academyName', academyName);
  }, [academyName]);

  useEffect(() => {
    setSafeStorage('logo', logo);
  }, [logo]);

  useEffect(() => {
    setSafeStorage('sidebarBanner', sidebarBanner);
  }, [sidebarBanner]);

  useEffect(() => {
    setSafeStorage('loginLogo', loginLogo);
  }, [loginLogo]);

  useEffect(() => {
    setSafeStorage('loginName', loginName);
  }, [loginName]);

  useEffect(() => {
    setSafeStorage('loginBgImage', loginBgImage);
  }, [loginBgImage]);

  useEffect(() => {
    try {
      localStorage.setItem('loginBgPresets', JSON.stringify(loginBgPresets));
    } catch (e) {
      if (e instanceof DOMException && e.name === 'QuotaExceededError') {
        console.error('Storage quota exceeded for presets');
      }
    }
  }, [loginBgPresets]);

  // Date ranges for charts
  const [alumnosRange, setAlumnosRange] = useState({ from: `${currentYear}-01-01`, to: `${currentYear}-12-31` });
  const [ingresosRange, setIngresosRange] = useState({ from: `${currentYear}-01-01`, to: `${currentYear}-12-31` });

  // Categories State
  const [categories, setCategories] = useState(() => {
    const saved = localStorage.getItem('academyCategories');
    return saved ? JSON.parse(saved) : Array.from({ length: 15 }, (_, i) => (currentYear - 15 + i).toString());
  });

  useEffect(() => {
    localStorage.setItem('academyCategories', JSON.stringify(categories));
  }, [categories]);

  return (
    <div className="min-h-screen flex font-sans bg-slate-50/50">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 transform
        lg:translate-x-0 lg:static lg:inset-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="relative h-32 flex items-end p-6 overflow-hidden">
          {/* Banner Background */}
          {sidebarBanner && (
            <div className="absolute inset-0 z-0">
              <img 
                src={sidebarBanner} 
                alt="Sidebar Banner" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/40 to-transparent" />
            </div>
          )}
          
          <div className="relative z-10 flex items-center gap-3 w-full">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-md border border-white/30 rounded-xl flex items-center justify-center text-white shadow-lg overflow-hidden">
              {logo.startsWith('data:image') || logo.startsWith('http') ? (
                <img src={logo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-xl">{logo}</span>
              )}
            </div>
            <span className="font-bold text-white text-lg drop-shadow-md truncate">{academyName}</span>
          </div>
          
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="lg:hidden absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-xl transition-colors z-20"
          >
            <X size={20} className="text-white" />
          </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => { setActiveTab('dashboard'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <TrendingUp size={20} />
            <span className="font-medium">Dashboard</span>
          </button>
          <button 
            onClick={() => { setActiveTab('students-list'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'students-list' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Users size={20} />
            <span className="font-medium">Alumnos</span>
          </button>
          <button 
            onClick={() => { setActiveTab('students-reg'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'students-reg' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <UserPlus size={20} />
            <span className="font-medium">Registro de Alumnos</span>
          </button>
          <button 
            onClick={() => { setActiveTab('pending-payments'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'pending-payments' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <AlertCircle size={20} />
            <span className="font-medium">Pagos Pendientes</span>
          </button>
          <button 
            onClick={() => { setActiveTab('teachers'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'teachers' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <GraduationCap size={20} />
            <span className="font-medium">Profesores</span>
          </button>
          <button 
            onClick={() => { setActiveTab('settings'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <SettingsIcon size={20} />
            <span className="font-medium">Configuración</span>
          </button>
        </nav>

        <div className="p-4 border-t border-slate-100">
          <Link to="/login" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors">
            <LogOut size={20} />
            <span className="font-medium">Cerrar Sesión</span>
          </Link>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center text-slate-600 overflow-hidden">
              {logo.startsWith('data:image') || logo.startsWith('http') ? (
                <img src={logo} alt="Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-sm font-bold">{logo}</span>
              )}
            </div>
            <span className="font-bold text-slate-800">{academyName}</span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <Menu size={24} className="text-slate-600" />
          </button>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Header & Date Selector */}
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-slate-800">Panel de Control</h1>
                <p className="text-slate-500 mt-1">Resumen general de la academia</p>
              </div>
              
              <div className="flex flex-wrap items-center gap-3 bg-white p-2 rounded-2xl shadow-sm border border-slate-100">
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-xl text-slate-600">
                  <Filter size={16} />
                  <span className="text-sm font-medium">Periodo:</span>
                </div>
                <input 
                  type="month" 
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="flex-1 sm:flex-none px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-sm font-medium text-slate-700 cursor-pointer"
                />
              </div>
            </header>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div 
                onClick={() => setActiveTab('students-list')}
                className="group bg-[#eff6ffff] rounded-3xl p-6 shadow-sm border border-blue-100/50 flex items-center gap-4 hover:shadow-md hover:scale-[1.02] transition-all duration-300 cursor-pointer"
              >
                <div className="w-14 h-14 bg-white/80 rounded-2xl flex items-center justify-center text-blue-600 shadow-sm group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                  <Users size={28} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-blue-600/70 uppercase tracking-wider">Alumnos Activos</p>
                  <p className="text-3xl font-bold text-slate-800">{activeStudentsCount}</p>
                  <p className="text-[10px] text-blue-400 mt-1 font-medium">Pagaron este mes</p>
                </div>
              </div>
              
              <div className="group bg-[#ecfef6ff] rounded-3xl p-6 shadow-sm border border-emerald-100/50 flex items-center gap-4 hover:shadow-md hover:scale-[1.02] transition-all duration-300 cursor-default">
                <div className="w-14 h-14 bg-white/80 rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-300">
                  <Coins size={28} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-emerald-600/70 uppercase tracking-wider">Ingresos Mensuales</p>
                  <p className="text-3xl font-bold text-slate-800">S/ {monthlyIncome.toLocaleString()}</p>
                  <p className="text-[10px] text-emerald-400 mt-1 font-medium">Recaudado este mes</p>
                </div>
              </div>

              <div 
                onClick={() => setActiveTab('pending-payments')}
                className="group bg-[#fff2f2ff] rounded-3xl p-6 shadow-sm border border-rose-100/50 flex items-center gap-4 hover:shadow-md hover:scale-[1.02] transition-all duration-300 cursor-pointer"
              >
                <div className="w-14 h-14 bg-white/80 rounded-2xl flex items-center justify-center text-rose-600 shadow-sm group-hover:bg-rose-600 group-hover:text-white transition-colors duration-300">
                  <AlertCircle size={28} />
                </div>
                <div>
                  <p className="text-[10px] font-bold text-rose-600/70 uppercase tracking-wider">Cuotas Pendientes</p>
                  <p className="text-3xl font-bold text-slate-800">{pendingPaymentsCount}</p>
                  <p className="text-[10px] text-rose-400 mt-1 font-medium">Sin pagar este mes</p>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Alumnos Activos Chart */}
              <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800">Alumnos Activos</h2>
                    <p className="text-sm text-slate-500">Evolución de deportistas al día</p>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase px-1">Desde</span>
                      <input 
                        type="date" 
                        value={alumnosRange.from}
                        onChange={(e) => setAlumnosRange(prev => ({ ...prev, from: e.target.value }))}
                        className="bg-transparent border-none text-xs font-bold text-slate-600 focus:ring-0 p-0"
                      />
                    </div>
                    <div className="w-px h-8 bg-slate-200 mx-1"></div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase px-1">Hasta</span>
                      <input 
                        type="date" 
                        value={alumnosRange.to}
                        onChange={(e) => setAlumnosRange(prev => ({ ...prev, to: e.target.value }))}
                        className="bg-transparent border-none text-xs font-bold text-slate-600 focus:ring-0 p-0"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#94a3b8', fontSize: 11}}
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#94a3b8', fontSize: 11}}
                      />
                      <Tooltip 
                        contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="alumnosActivos" 
                        stroke="#3b82f6" 
                        strokeWidth={4}
                        dot={{ r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: '#fff' }}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Ingresos Chart */}
              <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-slate-800">Ingresos Reales</h2>
                    <p className="text-sm text-slate-500">Recaudación por fecha de pago</p>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase px-1">Desde</span>
                      <input 
                        type="date" 
                        value={ingresosRange.from}
                        onChange={(e) => setIngresosRange(prev => ({ ...prev, from: e.target.value }))}
                        className="bg-transparent border-none text-xs font-bold text-slate-600 focus:ring-0 p-0"
                      />
                    </div>
                    <div className="w-px h-8 bg-slate-200 mx-1"></div>
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase px-1">Hasta</span>
                      <input 
                        type="date" 
                        value={ingresosRange.to}
                        onChange={(e) => setIngresosRange(prev => ({ ...prev, to: e.target.value }))}
                        className="bg-transparent border-none text-xs font-bold text-slate-600 focus:ring-0 p-0"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#94a3b8', fontSize: 11}}
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#94a3b8', fontSize: 11}}
                      />
                      <Tooltip 
                        contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="ingresos" 
                        stroke="#10b981" 
                        strokeWidth={4}
                        dot={{ r: 4, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'students-list' && (
          <StudentsList 
            categories={categories} 
            studentsData={studentsData} 
            setStudentsData={setStudentsData}
            selectedMonth={selectedMonth}
            getStudentMonthlyStatus={getStudentMonthlyStatus}
            onViewProfile={(id) => {
              setSelectedStudentId(id);
              setActiveTab('student-profile');
            }}
          />
        )}
        {activeTab === 'student-profile' && selectedStudentId && (
          <StudentProfile 
            student={studentsData.find(s => s.id === selectedStudentId)} 
            onBack={() => setActiveTab('students-list')}
            selectedMonth={selectedMonth}
            getStudentMonthlyStatus={getStudentMonthlyStatus}
            schedules={schedules}
            onAddEvaluation={() => setShowEvaluationModal(true)}
          />
        )}
        {activeTab === 'students-reg' && (
          <StudentRegistration 
            setStudentsData={setStudentsData} 
            selectedMonth={selectedMonth}
            categories={categories}
          />
        )}
        {activeTab === 'pending-payments' && (
          <PendingPayments 
            categories={categories} 
            studentsData={studentsData}
            setStudentsData={setStudentsData}
            selectedMonth={selectedMonth}
            getStudentMonthlyStatus={getStudentMonthlyStatus}
          />
        )}
        {activeTab === 'teachers' && <TeacherManagement categories={categories} />}
        {activeTab === 'settings' && (
          <SettingsView 
            academyName={academyName} 
            setAcademyName={setAcademyName} 
            logo={logo} 
            setLogo={setLogo}
            sidebarBanner={sidebarBanner}
            setSidebarBanner={setSidebarBanner}
            loginLogo={loginLogo}
            setLoginLogo={setLoginLogo}
            loginName={loginName}
            setLoginName={setLoginName}
            loginBgImage={loginBgImage}
            setLoginBgImage={setLoginBgImage}
            loginBgPresets={loginBgPresets}
            setLoginBgPresets={setLoginBgPresets}
            schedules={schedules}
            setSchedules={setSchedules}
            categories={categories}
            setCategories={setCategories}
          />
        )}
        {showEvaluationModal && selectedStudentId && (
          <EvaluationModal
            isOpen={showEvaluationModal}
            onClose={() => setShowEvaluationModal(false)}
            onSave={(evaluation: any) => {
              setStudentsData(prev => prev.map(s => {
                if (s.id === selectedStudentId) {
                  const newEvaluations = [...(s.evaluations || []), evaluation];
                  const avgScore = (evaluation.performance.technical + evaluation.performance.physical + evaluation.performance.tactical + evaluation.performance.psychological) / 4;
                  
                  // Update performance history
                  const month = new Date(evaluation.date).toLocaleString('es-ES', { month: 'short' }).replace('.', '');
                  const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
                  const newPerformance = [...(s.performance || [])];
                  const existingMonthIndex = newPerformance.findIndex(p => p.name === capitalizedMonth);
                  
                  if (existingMonthIndex >= 0) {
                    newPerformance[existingMonthIndex] = { ...newPerformance[existingMonthIndex], valor: avgScore };
                  } else {
                    newPerformance.push({ name: capitalizedMonth, valor: avgScore });
                  }

                  // Update skills radar
                  const newSkills = [
                    { subject: 'Técnico', A: evaluation.performance.technical, fullMark: 100 },
                    { subject: 'Físico', A: evaluation.performance.physical, fullMark: 100 },
                    { subject: 'Táctico', A: evaluation.performance.tactical, fullMark: 100 },
                    { subject: 'Psicológico', A: evaluation.performance.psychological, fullMark: 100 },
                    { subject: 'Asistencia', A: s.skills?.find((sk: any) => sk.subject === 'Asistencia')?.A || 85, fullMark: 100 },
                    { subject: 'Biométrico', A: (evaluation.biometrics.weight + (evaluation.biometrics.height * 10)) / 2, fullMark: 100 },
                  ];

                  return {
                    ...s,
                    evaluations: newEvaluations,
                    performance: newPerformance,
                    skills: newSkills,
                    biometrics: evaluation.biometrics
                  };
                }
                return s;
              }));
              setShowEvaluationModal(false);
            }}
            studentName={studentsData.find(s => s.id === selectedStudentId)?.name || ''}
          />
        )}
        </main>
      </div>
    </div>
  );
}

function StudentsList({ 
  categories, 
  studentsData, 
  setStudentsData,
  selectedMonth,
  getStudentMonthlyStatus,
  onViewProfile
}: { 
  categories: string[], 
  studentsData: any[], 
  setStudentsData: React.Dispatch<React.SetStateAction<any[]>>,
  selectedMonth: string,
  getStudentMonthlyStatus: (student: any, month: string) => string,
  onViewProfile: (id: number) => void
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDataModal, setShowDataModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [selectedStudents, setSelectedStudents] = useState<number[]>([]);

  const filteredStudents = studentsData.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          student.dni.includes(searchTerm);
    const matchesCategory = categoryFilter === 'all' || student.category === categoryFilter;
    
    const monthlyStatus = getStudentMonthlyStatus(student, selectedMonth);
    const matchesStatus = statusFilter === 'all' || monthlyStatus === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleEditStudent = (student: any) => {
    setSelectedStudent(student);
    setShowEditModal(true);
  };

  const handleViewData = (student: any) => {
    setSelectedStudent(student);
    setShowDataModal(true);
  };

  const toggleSelectAll = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([]);
    } else {
      setSelectedStudents(filteredStudents.map(s => s.id));
    }
  };

  const toggleSelectStudent = (id: number) => {
    setSelectedStudents(prev => 
      prev.includes(id) ? prev.filter(sid => sid !== id) : [...prev, id]
    );
  };

  const exportToCSV = () => {
    const selectedData = studentsData.filter(s => selectedStudents.includes(s.id));
    const headers = [
      'Nombre Completo', 
      'DNI', 
      'Categoría', 
      'Estado', 
      'Tutor 1 Nombre', 
      'Tutor 1 Correo', 
      'Tutor 1 Teléfono', 
      'Tutor 2 Nombre', 
      'Tutor 2 Correo', 
      'Tutor 2 Teléfono'
    ];
    const rows = selectedData.map(s => [
      s.name,
      s.dni,
      s.category,
      s.status === 'active' ? 'Activo' : 'Inactivo',
      s.parents[0]?.name || '',
      s.parents[0]?.email || '',
      s.parents[0]?.phone || '',
      s.parents[1]?.name || '',
      s.parents[1]?.email || '',
      s.parents[1]?.phone || ''
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "alumnos_seleccionados.csv");
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const bulkUpdateStatus = (newStatus: 'active' | 'inactive') => {
    setStudentsData(prev => prev.map(s => 
      selectedStudents.includes(s.id) ? { ...s, status: newStatus } : s
    ));
    setSelectedStudents([]);
  };

  const toggleStudentStatus = (id: number) => {
    setStudentsData(prev => prev.map(s => 
      s.id === id ? { ...s, status: s.status === 'active' ? 'inactive' : 'active' } : s
    ));
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Alumnos</h1>
          <p className="text-slate-500 mt-1">Base de datos histórica y gestión de integrantes</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por nombre o DNI..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm w-64 shadow-sm"
            />
          </div>

          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="pl-10 pr-8 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm appearance-none shadow-sm"
            >
              <option value="all">Todas las categorías</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>Categoría {cat}</option>
              ))}
            </select>
          </div>

          <div className="relative">
            <Shield className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="pl-10 pr-8 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm appearance-none shadow-sm"
            >
              <option value="all">Todos los estados</option>
              <option value="active">Activos (Pagado)</option>
              <option value="pending">Pendientes (Sin pagar)</option>
              <option value="inactive">Inactivos (Baja)</option>
            </select>
          </div>
        </div>
      </header>

      {/* Bulk Actions Bar */}
      {selectedStudents.length > 0 && (
        <div className="bg-blue-600 text-white px-6 py-4 rounded-2xl shadow-lg shadow-blue-500/20 flex items-center justify-between animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-4">
            <div className="bg-white/20 px-3 py-1 rounded-lg font-bold text-sm">
              {selectedStudents.length} seleccionados
            </div>
            <p className="text-sm font-medium hidden sm:block">Acciones masivas disponibles</p>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={exportToCSV}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-bold transition-all"
            >
              <Download size={16} />
              Exportar CSV
            </button>
            <button 
              onClick={() => bulkUpdateStatus('inactive')}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-bold transition-all"
            >
              <UserMinus size={16} />
              Dar de baja
            </button>
            <button 
              onClick={() => bulkUpdateStatus('active')}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-bold transition-all"
            >
              <UserCheck size={16} />
              Reincorporar
            </button>
            <div className="w-px h-6 bg-white/20 mx-2"></div>
            <button 
              onClick={() => setSelectedStudents([])}
              className="p-2 hover:bg-white/10 rounded-xl transition-all"
            >
              <X size={20} />
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-xs uppercase tracking-wider">
                <th className="px-6 py-4 w-10">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    checked={selectedStudents.length === filteredStudents.length && filteredStudents.length > 0}
                    onChange={toggleSelectAll}
                  />
                </th>
                <th className="px-6 py-4 font-semibold">Nombre Completo</th>
                <th className="px-6 py-4 font-semibold">DNI</th>
                <th className="px-6 py-4 font-semibold">Categoría</th>
                <th className="px-6 py-4 font-semibold">Estado</th>
                <th className="px-6 py-4 font-semibold">Perfil</th>
                <th className="px-6 py-4 font-semibold">Datos</th>
                <th className="px-6 py-4 font-semibold text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredStudents.map((student) => (
                <tr key={student.id} className={`hover:bg-slate-50/50 transition-colors ${student.status === 'inactive' ? 'opacity-60' : ''}`}>
                  <td className="px-6 py-4">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                      checked={selectedStudents.includes(student.id)}
                      onChange={() => toggleSelectStudent(student.id)}
                    />
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-700">{student.name}</td>
                  <td className="px-6 py-4 text-slate-500">{student.dni}</td>
                  <td className="px-6 py-4 text-slate-500">{student.category}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      getStudentMonthlyStatus(student, selectedMonth) === 'active' 
                        ? 'bg-emerald-100 text-emerald-700' 
                        : getStudentMonthlyStatus(student, selectedMonth) === 'pending'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-slate-100 text-slate-500'
                    }`}>
                      {getStudentMonthlyStatus(student, selectedMonth) === 'active' ? 'Activo' : 
                       getStudentMonthlyStatus(student, selectedMonth) === 'pending' ? 'Pendiente' : 'Inactivo'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => onViewProfile(student.id)}
                      className="text-blue-600 hover:text-blue-800 font-bold text-sm"
                    >
                      Ver Perfil
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => handleViewData(student)}
                      className="text-slate-600 hover:text-slate-800 font-bold text-sm"
                    >
                      Ver Datos
                    </button>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleEditStudent(student)}
                      className="text-slate-400 hover:text-blue-600 transition-colors px-2 font-medium text-sm"
                    >
                      Editar
                    </button>
                    {student.status === 'active' ? (
                      <button 
                        onClick={() => toggleStudentStatus(student.id)}
                        className="text-slate-400 hover:text-rose-600 transition-colors px-2 font-medium text-sm"
                      >
                        Dar de baja
                      </button>
                    ) : (
                      <button 
                        onClick={() => toggleStudentStatus(student.id)}
                        className="text-slate-400 hover:text-emerald-600 transition-colors px-2 font-medium text-sm"
                      >
                        Reincorporar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Student Modal */}
      <EditStudentModal 
        student={selectedStudent} 
        isOpen={showEditModal} 
        onClose={() => setShowEditModal(false)} 
        categories={categories}
      />

      {/* Student Data Modal */}
      <StudentDataModal 
        student={selectedStudent}
        isOpen={showDataModal}
        onClose={() => setShowDataModal(false)}
      />
    </div>
  );
}

function StudentDataModal({ student, isOpen, onClose }: any) {
  if (!isOpen || !student) return null;

  const calculateAge = (birthDateStr: string) => {
    if (!birthDateStr) return 'N/A';
    try {
      const [day, month, year] = birthDateStr.split('/').map(Number);
      const birthDate = new Date(year, month - 1, day);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age;
    } catch (e) {
      return 'N/A';
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-[40px] w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center text-xl font-bold shadow-lg shadow-blue-500/20">
              {student.name.charAt(0)}
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-800">Información del Alumno</h3>
              <p className="text-slate-500 text-sm">Datos personales y de contacto</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
            <X size={24} className="text-slate-400" />
          </button>
        </div>

        <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
          {/* Student Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Nombre Completo</p>
              <p className="text-lg font-bold text-slate-700">{student.name}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Categoría</p>
              <p className="text-lg font-bold text-blue-600">Categoría {student.category}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">DNI</p>
              <p className="text-lg font-bold text-slate-700">{student.dni}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Edad</p>
              <p className="text-lg font-bold text-slate-700">{calculateAge(student.birthDate)} años</p>
            </div>
          </div>

          <div className="h-px bg-slate-100"></div>

          {/* Tutors Info */}
          <div className="space-y-6">
            <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Users size={18} className="text-emerald-500" />
              Datos de los Tutores
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {student.parents.map((parent: any, idx: number) => (
                <div key={idx} className="p-5 bg-slate-50 rounded-3xl border border-slate-100 space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-slate-800">{parent.name}</p>
                    <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-lg uppercase">{parent.role}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 text-slate-600">
                      <Phone size={14} className="text-slate-400" />
                      <span className="text-sm font-medium">{parent.phone}</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-600">
                      <MapPin size={14} className="text-slate-400" />
                      <span className="text-sm font-medium truncate">{parent.email}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <a 
                      href={`https://wa.me/${parent.phone.replace(/\D/g, '')}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-emerald-500 text-white rounded-xl text-xs font-bold hover:bg-emerald-600 transition-all shadow-sm"
                    >
                      WhatsApp
                    </a>
                    <a 
                      href={`mailto:${parent.email}`}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-white text-slate-600 border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-50 transition-all shadow-sm"
                    >
                      Email
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-8 bg-slate-50 flex justify-end">
          <button 
            onClick={onClose}
            className="px-8 py-3 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-900 transition-all shadow-lg"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}

function StudentProfile({ student, onBack, selectedMonth, getStudentMonthlyStatus, schedules, onAddEvaluation }: any) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    setCurrentPage(1);
  }, [student?.id, student?.name, student?.evaluations?.length]);

  if (!student) return null;

  const monthlyStatus = getStudentMonthlyStatus(student, selectedMonth);

  const studentSchedules = schedules.filter((s: any) => s.category === 'Todas' || s.category === student.category);

  const getDaysInMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-').map(Number);
    return new Date(year, month, 0).getDate();
  };

  const getFirstDayOfMonth = (monthStr: string) => {
    const [year, month] = monthStr.split('-').map(Number);
    return new Date(year, month - 1, 1).getDay(); // 0 = Sunday, 1 = Monday...
  };

  const daysInMonth = getDaysInMonth(selectedMonth);
  const firstDay = getFirstDayOfMonth(selectedMonth);
  // Adjust first day to start on Monday (0 = Monday, 6 = Sunday)
  const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1;

  const dayNames = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

  const latestEvaluation = student.evaluations?.[student.evaluations.length - 1];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-50 rounded-2xl transition-all text-slate-600 font-bold text-sm shadow-sm border border-slate-100 group"
          >
            <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
            Volver
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Perfil del Alumno</h1>
            <p className="text-slate-500 mt-1">Detalle académico y deportivo</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={onAddEvaluation}
            className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all"
          >
            <TrendingUp size={18} />
            Nueva Evaluación
          </button>
          <div className={`px-4 py-2 rounded-2xl font-bold text-sm flex items-center gap-2 ${
            monthlyStatus === 'active' ? 'bg-emerald-100 text-emerald-700' : 
            monthlyStatus === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
          }`}>
            <div className={`w-2 h-2 rounded-full ${
              monthlyStatus === 'active' ? 'bg-emerald-500' : 
              monthlyStatus === 'pending' ? 'bg-amber-500' : 'bg-slate-400'
            }`} />
            {monthlyStatus === 'active' ? 'Activo (Pagado)' : 
             monthlyStatus === 'pending' ? 'Pendiente' : 'Inactivo'}
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Basic Info & Attendance */}
        <div className="space-y-8">
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 flex flex-col items-center text-center space-y-4">
            <div className="relative">
              <div className="w-32 h-32 rounded-[40px] overflow-hidden border-4 border-slate-50 shadow-xl">
                <img 
                  src={student.photo || `https://ui-avatars.com/api/?name=${encodeURIComponent(student.name)}&background=random&size=200`} 
                  alt={student.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg border-4 border-white">
                <Camera size={16} />
              </div>
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{student.name}</h2>
              <p className="text-blue-600 font-bold text-sm uppercase tracking-wider">Categoría {student.category}</p>
            </div>

            <div className="w-full grid grid-cols-2 gap-3 pt-4">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[10px] font-bold text-slate-400 uppercase">DNI</p>
                <p className="text-sm font-bold text-slate-700">{student.dni}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Edad</p>
                <p className="text-sm font-bold text-slate-700">12 años</p>
              </div>
            </div>
          </div>

          {/* Biometrics Section */}
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Shield size={20} className="text-blue-500" />
              Datos Biométricos
            </h3>
            <div className="grid grid-cols-3 gap-3">
              <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 text-center">
                <p className="text-[10px] font-bold text-blue-600 uppercase">Peso</p>
                <p className="text-lg font-bold text-slate-800">{student.biometrics?.weight || '--'} <span className="text-[10px] font-medium">kg</span></p>
              </div>
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-center">
                <p className="text-[10px] font-bold text-emerald-600 uppercase">Talla</p>
                <p className="text-lg font-bold text-slate-800">{student.biometrics?.height || '--'} <span className="text-[10px] font-medium">m</span></p>
              </div>
              <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100 text-center">
                <p className="text-[10px] font-bold text-purple-600 uppercase">IMC</p>
                <p className="text-lg font-bold text-slate-800">{student.biometrics?.imc?.toFixed(1) || '--'}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Calendar size={20} className="text-emerald-500" />
              Asistencia {ACADEMY_MONTHS.find(m => m.id === selectedMonth)?.name}
            </h3>
            
            <div className="space-y-4">
              <div className="grid grid-cols-7 gap-1">
                {dayNames.map(name => (
                  <div key={name} className="text-[10px] font-bold text-slate-400 text-center py-1">
                    {name}
                  </div>
                ))}
                {Array.from({ length: adjustedFirstDay }).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square" />
                ))}
                {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(day => {
                  const isAttended = student.attendance?.includes(day);
                  return (
                    <div 
                      key={day}
                      className={`aspect-square rounded-lg flex items-center justify-center text-[10px] font-bold transition-all ${
                        isAttended 
                          ? 'bg-emerald-500 text-white shadow-md shadow-emerald-100' 
                          : 'bg-slate-50 text-slate-300'
                      }`}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
              
              <div className="flex items-center justify-between p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                <span className="text-xs font-bold text-emerald-700">Total asistencias</span>
                <span className="text-lg font-bold text-emerald-700">{student.attendance?.length || 0}</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Clock size={20} className="text-blue-500" />
              Horarios de Entrenamiento
            </h3>
            <div className="space-y-3">
              {studentSchedules.length > 0 ? (
                studentSchedules.map((s: any, i: number) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div>
                      <p className="text-xs font-bold text-slate-700">{s.day}</p>
                      <p className="text-[10px] text-slate-500">{s.category}</p>
                    </div>
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-lg">
                      {s.time}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-slate-400 text-center py-4 italic">No hay horarios específicos para esta categoría</p>
              )}
            </div>
          </div>
        </div>

        {/* Middle Column: Performance Curve & Notes */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp size={20} className="text-blue-500" />
                Curva de Rendimiento
              </h3>
              <select className="text-xs font-bold text-slate-500 bg-slate-50 border-none rounded-lg focus:ring-0">
                <option>Último mes</option>
                <option>Trimestre</option>
              </select>
            </div>

            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={student.performance || []}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} domain={[0, 100]} />
                  <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} />
                  <Area type="monotone" dataKey="valor" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Shield size={20} className="text-purple-500" />
                Radar de Habilidades
              </h3>
              <div className="h-[250px] w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={student.skills || []}>
                    <PolarGrid stroke="#f1f5f9" />
                    <PolarAngleAxis dataKey="subject" tick={{fill: '#64748b', fontSize: 10, fontWeight: 'bold'}} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                    <Radar
                      name={student.name}
                      dataKey="A"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.5}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <AlertCircle size={20} className="text-amber-500" />
                Evaluación de rendimiento
              </h3>
              <div className="space-y-4">
                {latestEvaluation ? (
                  <>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-xs">👨‍🏫</div>
                      <div>
                        <p className="text-xs font-bold text-slate-800">Prof. Carlos Rodríguez</p>
                        <p className="text-[10px] text-slate-400">Última evaluación: {new Date(latestEvaluation.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-xs text-slate-400 text-center py-4 italic">No hay evaluaciones registradas aún.</p>
                )}
                <button 
                  onClick={onAddEvaluation}
                  className="w-full py-3 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 text-xs font-bold hover:border-blue-400 hover:text-blue-500 transition-all"
                >
                  + Añadir nueva evaluación
                </button>
              </div>
            </div>
          </div>

          {/* Evaluation History Section */}
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <History size={20} className="text-blue-500" />
                Histórico de Evaluaciones
              </h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b border-slate-100">
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fecha</th>
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Rendimiento</th>
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Biometría</th>
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Observaciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {student.evaluations && student.evaluations.length > 0 ? (
                    (() => {
                      const sortedEvaluations = [...student.evaluations].reverse();
                      const indexOfLastItem = currentPage * itemsPerPage;
                      const indexOfFirstItem = indexOfLastItem - itemsPerPage;
                      const currentItems = sortedEvaluations.slice(indexOfFirstItem, indexOfLastItem);
                      const totalPages = Math.ceil(sortedEvaluations.length / itemsPerPage);

                      return (
                        <>
                          {currentItems.map((evalItem: any, idx: number) => (
                            <tr key={idx} className="group hover:bg-slate-50/50 transition-colors">
                              <td className="py-4">
                                <span className="text-xs font-bold text-slate-700">{new Date(evalItem.date).toLocaleDateString()}</span>
                              </td>
                              <td className="py-4">
                                <div className="flex flex-wrap gap-1">
                                  <span className="text-[9px] px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md font-bold">
                                    Téc: {evalItem.performance?.technical}
                                  </span>
                                  <span className="text-[9px] px-1.5 py-0.5 bg-emerald-50 text-emerald-600 rounded-md font-bold">
                                    Fís: {evalItem.performance?.physical}
                                  </span>
                                  <span className="text-[9px] px-1.5 py-0.5 bg-amber-50 text-amber-600 rounded-md font-bold">
                                    Tác: {evalItem.performance?.tactical}
                                  </span>
                                  <span className="text-[9px] px-1.5 py-0.5 bg-purple-50 text-purple-600 rounded-md font-bold">
                                    Psi: {evalItem.performance?.psychological}
                                  </span>
                                </div>
                              </td>
                              <td className="py-4">
                                <div className="text-[10px] text-slate-500">
                                  <p>Peso: {evalItem.biometrics?.weight}kg</p>
                                  <p>Talla: {evalItem.biometrics?.height}m</p>
                                  <p>IMC: {evalItem.biometrics?.imc?.toFixed(1)}</p>
                                </div>
                              </td>
                              <td className="py-4">
                                <p className="text-xs text-slate-600 line-clamp-2 italic">
                                  {evalItem.notes || 'Sin observaciones'}
                                </p>
                              </td>
                            </tr>
                          ))}
                          {totalPages > 1 && (
                            <tr>
                              <td colSpan={4} className="py-6">
                                <div className="flex items-center justify-center gap-4">
                                  <button
                                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                    disabled={currentPage === 1}
                                    className={`p-2 rounded-xl border border-slate-200 transition-all ${
                                      currentPage === 1 ? 'text-slate-300 bg-slate-50' : 'text-slate-600 hover:bg-slate-50'
                                    }`}
                                  >
                                    <ChevronLeft size={20} />
                                  </button>
                                  <span className="text-xs font-bold text-slate-500">
                                    Página {currentPage} de {totalPages}
                                  </span>
                                  <button
                                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                    disabled={currentPage === totalPages}
                                    className={`p-2 rounded-xl border border-slate-200 transition-all ${
                                      currentPage === totalPages ? 'text-slate-300 bg-slate-50' : 'text-slate-600 hover:bg-slate-50'
                                    }`}
                                  >
                                    <ChevronRight size={20} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          )}
                        </>
                      );
                    })()
                  ) : (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-xs text-slate-400 italic">
                        No hay historial de evaluaciones disponible
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EditStudentModal({ student, isOpen, onClose, categories }: any) {
  const [formData, setFormData] = useState({
    name: '',
    dni: '',
    category: '',
    birthDate: '',
    phone: '',
    email: '',
    parents: [] as any[]
  });

  useEffect(() => {
    if (student) {
      setFormData({
        name: student.name || '',
        dni: student.dni || '',
        category: student.category || '',
        birthDate: student.birthDate || '',
        phone: student.phone || '',
        email: student.email || '',
        parents: student.parents || []
      });
    }
  }, [student]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h3 className="text-xl font-bold text-slate-800">Editar Alumno</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-xl transition-colors">
            <X size={20} className="text-slate-400" />
          </button>
        </div>
        
        <form className="p-8 space-y-6 max-h-[70vh] overflow-y-auto" onSubmit={(e) => { e.preventDefault(); onClose(); }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nombre Completo</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">DNI</label>
              <input 
                type="text" 
                value={formData.dni}
                onChange={(e) => setFormData({...formData, dni: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Categoría</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all appearance-none"
              >
                {categories.map((cat: string) => (
                  <option key={cat} value={cat}>Categoría {cat}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Fecha de Nacimiento</label>
              <input 
                type="text" 
                value={formData.birthDate}
                onChange={(e) => setFormData({...formData, birthDate: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
              />
            </div>
          </div>

          {/* Tutors Section in Edit Modal */}
          <div className="space-y-6 pt-4">
            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Users size={16} className="text-emerald-500" />
              Datos de los Tutores
            </h4>
            
            {formData.parents.map((parent, idx) => (
              <div key={idx} className="p-6 border border-slate-100 rounded-[24px] space-y-4 bg-slate-50/30">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg uppercase tracking-wider">
                    {parent.role}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Nombre</label>
                    <input 
                      type="text" 
                      value={parent.name}
                      onChange={(e) => {
                        const newParents = [...formData.parents];
                        newParents[idx] = { ...parent, name: e.target.value };
                        setFormData({ ...formData, parents: newParents });
                      }}
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Correo Electrónico</label>
                    <input 
                      type="email" 
                      value={parent.email}
                      onChange={(e) => {
                        const newParents = [...formData.parents];
                        newParents[idx] = { ...parent, email: e.target.value };
                        setFormData({ ...formData, parents: newParents });
                      }}
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Teléfono</label>
                    <input 
                      type="tel" 
                      value={parent.phone}
                      onChange={(e) => {
                        const newParents = [...formData.parents];
                        newParents[idx] = { ...parent, phone: e.target.value };
                        setFormData({ ...formData, parents: newParents });
                      }}
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all text-sm"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-6 flex gap-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-4 border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-1 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
            >
              Guardar Cambios
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function PendingPayments({ 
  categories, 
  studentsData, 
  setStudentsData, 
  selectedMonth,
  getStudentMonthlyStatus
}: { 
  categories: string[], 
  studentsData: any[], 
  setStudentsData: React.Dispatch<React.SetStateAction<any[]>>,
  selectedMonth: string,
  getStudentMonthlyStatus: (student: any, month: string) => string
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [selectedMonths, setSelectedMonths] = useState<string[]>([]);
  const [totalPayment, setTotalPayment] = useState('');

  const handleOpenPayment = (student: any) => {
    setSelectedStudent(student);
    setSelectedMonths([selectedMonth]); // Default to current selected month
    setTotalPayment('45'); // Default amount
    setShowPaymentModal(true);
  };

  const handleConfirmPayment = () => {
    if (!selectedStudent) return;
    
    setStudentsData(prev => prev.map(s => {
      if (s.id === selectedStudent.id) {
        // Add selected months to student's payments, avoiding duplicates
        const newPayments = [...s.payments];
        selectedMonths.forEach(m => {
          if (!newPayments.includes(m)) {
            newPayments.push(m);
          }
        });
        return { ...s, payments: newPayments };
      }
      return s;
    }));
    
    setShowPaymentModal(false);
  };

  const pendingStudents = studentsData.filter(student => {
    const monthlyStatus = getStudentMonthlyStatus(student, selectedMonth);
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || student.category === categoryFilter;
    return monthlyStatus === 'pending' && matchesSearch && matchesCategory;
  });

  const toggleMonth = (monthId: string) => {
    setSelectedMonths(prev => 
      prev.includes(monthId) 
        ? prev.filter(id => id !== monthId) 
        : [...prev, monthId]
    );
  };

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Pagos Pendientes</h1>
          <p className="text-slate-500 mt-1">Gestión de continuidad y cuotas del mes</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar alumno..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm w-72 shadow-sm"
            />
          </div>

          <div className="relative">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="pl-10 pr-8 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm appearance-none shadow-sm"
            >
              <option value="all">Todas las categorías</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>Categoría {cat}</option>
              ))}
            </select>
          </div>
        </div>
      </header>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-400 text-xs uppercase tracking-wider">
                <th className="px-6 py-4 font-semibold">Alumno</th>
                <th className="px-6 py-4 font-semibold">Categoría</th>
                <th className="px-6 py-4 font-semibold">Mes Actual</th>
                <th className="px-6 py-4 font-semibold">Estado</th>
                <th className="px-6 py-4 font-semibold text-right">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {pendingStudents.length > 0 ? (
                pendingStudents.map(student => (
                  <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-700">{student.name}</td>
                    <td className="px-6 py-4 text-slate-500">{student.category}</td>
                    <td className="px-6 py-4 text-slate-500">
                      {ACADEMY_MONTHS.find(m => m.id === selectedMonth)?.name || selectedMonth}
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-semibold">Pendiente</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleOpenPayment(student)}
                        className="text-blue-500 hover:text-blue-700 font-medium text-sm"
                      >
                        Registrar Pago
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-slate-400 font-medium">
                    No hay alumnos pendientes de pago para este mes.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-8 bg-blue-600 text-white relative">
              <button onClick={() => setShowPaymentModal(false)} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-xl transition-colors">
                <X size={20} />
              </button>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                  <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" />
                    <path d="M3 11h18" />
                    <circle cx="8" cy="6.5" r="1.5" />
                    <path d="M5 9.5c0-.8.7-1.5 1.5-1.5h3c.8 0 1.5.7 1.5 1.5" />
                    <path d="M14 5.5h4" />
                    <path d="M14 8h4" />
                    <path d="M12 13v6" />
                    <path d="M14 14.5a2 2 0 0 0-2-1.5h-1a1.5 1.5 0 0 0 0 3h1a1.5 1.5 0 0 1 0 3h-1a2 2 0 0 1-2-1.5" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Registro de Pago</h3>
                </div>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl">
                <p className="text-xs uppercase font-bold tracking-wider opacity-70">Alumno</p>
                <p className="text-lg font-bold">{selectedStudent?.name}</p>
              </div>
            </div>

            <div className="p-8 space-y-6 max-h-[60vh] overflow-y-auto">
              {/* Month Selection Grid */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <Calendar size={16} className="text-purple-500" />
                    Meses a Pagar
                  </label>
                  <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                    {selectedMonths.length} seleccionados
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ACADEMY_MONTHS.map((month) => (
                    <button
                      key={month.id}
                      type="button"
                      onClick={() => toggleMonth(month.id)}
                      className={`flex items-center justify-between px-3 py-2 rounded-xl border transition-all text-xs font-medium ${
                        selectedMonths.includes(month.id)
                          ? 'bg-purple-600 border-purple-600 text-white shadow-md shadow-purple-200'
                          : 'bg-white border-slate-200 text-slate-600 hover:border-purple-300'
                      }`}
                    >
                      {month.name}
                      {selectedMonths.includes(month.id) && <Check size={10} />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="h-px bg-slate-100"></div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Monto Total (S/)</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">S/</span>
                    <input 
                      type="number" 
                      value={totalPayment}
                      onChange={(e) => setTotalPayment(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none font-bold text-slate-800" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Método de Pago</label>
                  <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none appearance-none bg-white text-sm">
                    <option>Efectivo</option>
                    <option>Transferencia</option>
                    <option>Yape / Plin</option>
                    <option>Tarjeta Débito/Crédito</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Observaciones (Opcional)</label>
                <textarea className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none h-20 resize-none text-sm" placeholder="Ej. Pago parcial, nota del tutor..."></textarea>
              </div>

              <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                  <Check size={18} />
                </div>
                <p className="text-xs text-blue-700 font-medium">Se enviará un comprobante digital automáticamente al correo del tutor.</p>
              </div>
            </div>

            <div className="p-8 bg-slate-50 flex gap-4">
              <button onClick={() => setShowPaymentModal(false)} className="flex-1 py-3 rounded-xl font-medium text-slate-600 hover:bg-white transition-all">Cancelar</button>
              <button 
                onClick={handleConfirmPayment}
                className="flex-1 py-3 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
              >
                Confirmar Pago
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SettingsView({ 
  academyName, 
  setAcademyName, 
  logo, 
  setLogo,
  sidebarBanner,
  setSidebarBanner,
  loginLogo,
  setLoginLogo,
  loginName,
  setLoginName,
  loginBgImage,
  setLoginBgImage,
  loginBgPresets,
  setLoginBgPresets,
  schedules,
  setSchedules,
  categories,
  setCategories
}: { 
  academyName: string; 
  setAcademyName: (val: string) => void; 
  logo: string; 
  setLogo: (val: string) => void; 
  sidebarBanner: string;
  setSidebarBanner: (val: string) => void;
  loginLogo: string;
  setLoginLogo: (val: string) => void;
  loginName: string;
  setLoginName: (val: string) => void;
  loginBgImage: string;
  setLoginBgImage: (val: string) => void;
  loginBgPresets: string[];
  setLoginBgPresets: (val: string[]) => void;
  schedules: any[];
  setSchedules: (val: any[]) => void;
  categories: string[];
  setCategories: (val: string[]) => void;
}) {
  const [showNewAdminModal, setShowNewAdminModal] = useState(false);
  const [bannerUrl, setBannerUrl] = useState(sidebarBanner);
  const [loginBgUrl, setLoginBgUrl] = useState(loginBgImage);
  const [isSaving, setIsSaving] = useState(false);
  const [showSaved, setShowSaved] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    // Simulate saving delay
    setTimeout(() => {
      setIsSaving(false);
      setShowSaved(true);
      setTimeout(() => setShowSaved(false), 3000);
    }, 800);
  };
  const logoInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const loginLogoInputRef = useRef<HTMLInputElement>(null);
  const loginBgInputRef = useRef<HTMLInputElement>(null);
  
  const menuOptions = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'students-list', label: 'Alumnos' },
    { id: 'students-reg', label: 'Registro de Alumnos' },
    { id: 'pending-payments', label: 'Pagos Pendientes' },
    { id: 'teachers', label: 'Profesores' },
  ];

  const bannerPresets = [
    'https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1517466787929-bc90951d0974?q=80&w=2000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=2000&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1431324155629-1a6eda1eed2d?q=80&w=2000&auto=format&fit=crop'
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      if (setter === setLoginBgImage && !file.type.includes('jpeg') && !file.type.includes('jpg')) {
        alert('Por favor selecciona una imagen en formato JPG.');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_WIDTH = 1280;
          const MAX_HEIGHT = 720;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
          
          if (setter === setLoginBgImage) {
            const newPresets = [...loginBgPresets, compressedBase64];
            if (newPresets.length > 4) newPresets.shift();
            try {
              setLoginBgPresets(newPresets);
              setLoginBgUrl(compressedBase64);
              setter(compressedBase64);
            } catch (error) {
              alert('No se pudo guardar la imagen por falta de espacio.');
            }
          } else {
            setter(compressedBase64);
            if (setter === setSidebarBanner) setBannerUrl(compressedBase64);
          }
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const addSchedule = () => {
    setSchedules([...schedules, { day: 'Lunes', time: '00:00 - 00:00', category: 'Todas' }]);
  };

  const removeSchedule = (index: number) => {
    setSchedules(schedules.filter((_, i) => i !== index));
  };

  const updateSchedule = (index: number, field: string, value: string) => {
    const newSchedules = [...schedules];
    newSchedules[index] = { ...newSchedules[index], [field]: value };
    setSchedules(newSchedules);
  };

  const [newCategory, setNewCategory] = useState('');

  const addCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      setCategories([...categories, newCategory.trim()].sort((a, b) => b.localeCompare(a)));
      setNewCategory('');
    }
  };

  const removeCategory = (cat: string) => {
    setCategories(categories.filter(c => c !== cat));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10">
      <header>
        <h1 className="text-3xl font-bold text-slate-800">Configuración del Sistema</h1>
        <p className="text-slate-500 mt-1">Administra la identidad de tu academia y accesos del personal</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Branding Section */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Camera size={20} className="text-blue-500" />
              Identidad de la Academia
            </h2>
            
            <div className="flex flex-col items-center gap-4">
              <div className="relative group">
                <div className="w-24 h-24 bg-slate-100 rounded-3xl flex items-center justify-center text-4xl shadow-inner border-2 border-dashed border-slate-200 group-hover:border-blue-400 transition-all overflow-hidden">
                  {logo.startsWith('data:image') || logo.startsWith('http') ? (
                    <img src={logo} alt="Logo Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    logo
                  )}
                </div>
                <button 
                  onClick={() => logoInputRef.current?.click()}
                  className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2 rounded-xl shadow-lg hover:scale-110 transition-transform"
                >
                  <Camera size={16} />
                </button>
                <input 
                  type="file" 
                  ref={logoInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleFileChange(e, setLogo)} 
                />
              </div>
              <p className="text-xs text-slate-400 text-center">Logo del Sidebar</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Nombre de la Academia</label>
              <input 
                type="text" 
                value={academyName}
                onChange={(e) => setAcademyName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
              />
            </div>

            <div className="h-px bg-slate-100"></div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-slate-700">Banner del Sidebar</label>
                <button 
                  onClick={() => bannerInputRef.current?.click()}
                  className="text-xs font-bold text-blue-600 flex items-center gap-1 hover:text-blue-700 transition-colors"
                >
                  <Upload size={12} />
                  Subir Imagen
                </button>
                <input 
                  type="file" 
                  ref={bannerInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleFileChange(e, setSidebarBanner)} 
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                {bannerPresets.map((url, idx) => (
                  <button 
                    key={idx}
                    onClick={() => { setBannerUrl(url); setSidebarBanner(url); }}
                    className={`relative h-16 rounded-xl overflow-hidden border-2 transition-all ${bannerUrl === url ? 'border-blue-600 ring-2 ring-blue-500/20' : 'border-transparent hover:border-slate-200'}`}
                  >
                    <img src={url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    {bannerUrl === url && (
                      <div className="absolute inset-0 bg-blue-600/20 flex items-center justify-center">
                        <Check size={16} className="text-white" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">O URL personalizada</p>
                <input 
                  type="text" 
                  value={bannerUrl}
                  onChange={(e) => { setBannerUrl(e.target.value); setSidebarBanner(e.target.value); }}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Users size={20} className="text-blue-500" />
              Gestión de Categorías
            </h2>
            
            <div className="space-y-4">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="Ej: 2015"
                  className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 outline-none"
                />
                <button 
                  onClick={addCategory}
                  className="px-4 py-2 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all"
                >
                  Agregar
                </button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <div key={cat} className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-xl group">
                    <span className="text-sm font-bold text-slate-600">{cat}</span>
                    <button 
                      onClick={() => removeCategory(cat)}
                      className="text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Calendar size={20} className="text-emerald-500" />
              Horarios de Entrenamiento
            </h2>
            
            <div className="space-y-4">
              {schedules.map((schedule, index) => (
                <div key={index} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-3 relative group">
                  <button 
                    onClick={() => removeSchedule(index)}
                    className="absolute top-2 right-2 p-1 text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <X size={16} />
                  </button>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Día</label>
                      <select 
                        value={schedule.day}
                        onChange={(e) => updateSchedule(index, 'day', e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 outline-none"
                      >
                        {['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'].map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Horario</label>
                      <input 
                        type="text" 
                        value={schedule.time}
                        onChange={(e) => updateSchedule(index, 'time', e.target.value)}
                        placeholder="17:00 - 18:30"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 outline-none"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Categoría</label>
                    <select 
                      value={schedule.category}
                      onChange={(e) => updateSchedule(index, 'category', e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500/20 outline-none"
                    >
                      <option value="Todas">Todas</option>
                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
              
              <button 
                onClick={addSchedule}
                className="w-full py-3 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 hover:text-blue-600 hover:border-blue-200 hover:bg-blue-50 transition-all text-sm font-bold flex items-center justify-center gap-2"
              >
                <UserPlus size={18} />
                Agregar Horario
              </button>
            </div>
          </div>

          {/* Login Customization Section */}
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <LogOut size={20} className="text-purple-500" />
              Personalización de Login
            </h2>

            <div className="flex flex-col items-center gap-4">
              <div className="relative group">
                <div className="w-24 h-24 bg-slate-100 rounded-3xl flex items-center justify-center text-4xl shadow-inner border-2 border-dashed border-slate-200 group-hover:border-purple-400 transition-all overflow-hidden">
                  {loginLogo.startsWith('data:image') || loginLogo.startsWith('http') ? (
                    <img src={loginLogo} alt="Login Logo Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    loginLogo
                  )}
                </div>
                <button 
                  onClick={() => loginLogoInputRef.current?.click()}
                  className="absolute -bottom-2 -right-2 bg-purple-600 text-white p-2 rounded-xl shadow-lg hover:scale-110 transition-transform"
                >
                  <Camera size={16} />
                </button>
                <input 
                  type="file" 
                  ref={loginLogoInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={(e) => handleFileChange(e, setLoginLogo)} 
                />
              </div>
              <p className="text-xs text-slate-400 text-center">Logo de la página de Login</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Título de Bienvenida</label>
              <input 
                type="text" 
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 outline-none transition-all"
                placeholder="Ej. Bienvenido"
              />
            </div>

            <div className="h-px bg-slate-100"></div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-slate-700">Fondo de Login</label>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => { setLoginBgUrl('none'); setLoginBgImage('none'); }}
                    className="text-xs font-bold text-rose-500 flex items-center gap-1 hover:text-rose-600 transition-colors"
                  >
                    <X size={12} />
                    Eliminar fondo
                  </button>
                  <button 
                    onClick={() => loginBgInputRef.current?.click()}
                    className="text-xs font-bold text-purple-600 flex items-center gap-1 hover:text-purple-700 transition-colors"
                  >
                    <Upload size={12} />
                    Subir Imagen (JPG)
                  </button>
                </div>
                <input 
                  type="file" 
                  ref={loginBgInputRef} 
                  className="hidden" 
                  accept=".jpg,.jpeg" 
                  onChange={(e) => handleFileChange(e, setLoginBgImage)} 
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                {loginBgPresets.map((url, idx) => (
                  <button 
                    key={idx}
                    onClick={() => { setLoginBgUrl(url); setLoginBgImage(url); }}
                    className={`relative h-16 rounded-xl overflow-hidden border-2 transition-all ${loginBgUrl === url ? 'border-purple-600 ring-2 ring-purple-500/20' : 'border-transparent hover:border-slate-200'}`}
                  >
                    <img src={url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    {loginBgUrl === url && (
                      <div className="absolute inset-0 bg-purple-600/20 flex items-center justify-center">
                        <Check size={16} className="text-white" />
                      </div>
                    )}
                  </button>
                ))}
                
                {loginBgUrl === 'none' && (
                  <div className="relative h-16 rounded-xl overflow-hidden border-2 border-purple-600 ring-2 ring-purple-500/20 bg-slate-100 flex items-center justify-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Sin fondo</span>
                    <div className="absolute inset-0 bg-purple-600/20 flex items-center justify-center">
                      <Check size={16} className="text-white" />
                    </div>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">O URL personalizada</p>
                <input 
                  type="text" 
                  value={loginBgUrl}
                  onChange={(e) => { setLoginBgUrl(e.target.value); setLoginBgImage(e.target.value); }}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 outline-none transition-all"
                />
              </div>
            </div>

            <button 
              onClick={handleSave}
              className={`w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
                showSaved 
                  ? 'bg-green-500 text-white' 
                  : 'bg-slate-800 text-white hover:bg-slate-900'
              }`}
            >
              {isSaving ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : showSaved ? (
                <>
                  <Check size={18} />
                  Cambios Guardados
                </>
              ) : (
                'Guardar Cambios'
              )}
            </button>
          </div>
        </div>

        {/* Admins Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Shield size={20} className="text-emerald-500" />
                Administradores y Accesos
              </h2>
              <button 
                onClick={() => setShowNewAdminModal(true)}
                className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-sm font-bold hover:bg-blue-100 transition-all flex items-center gap-2"
              >
                <UserPlus size={16} />
                Nuevo Acceso
              </button>
            </div>

            <div className="space-y-4">
              {/* Admin Card Item */}
              <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-50 bg-slate-50/30">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center font-bold">
                    JD
                  </div>
                  <div>
                    <p className="font-bold text-slate-800">Juan Delgado</p>
                    <p className="text-xs text-slate-500">juan.delgado@academy.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-bold uppercase">Admin</span>
                  <button className="text-slate-400 hover:text-blue-600 font-medium text-sm">Permisos</button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-50 bg-slate-50/30">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center font-bold">
                    MR
                  </div>
                  <div>
                    <p className="font-bold text-slate-800">María Rojas</p>
                    <p className="text-xs text-slate-500">m.rojas@academy.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase">Editor</span>
                  <button className="text-slate-400 hover:text-blue-600 font-medium text-sm">Permisos</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* New Admin Modal */}
      {showNewAdminModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-8 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-slate-800">Crear Nuevo Acceso</h3>
                <p className="text-slate-500 text-sm">Define los datos y permisos del nuevo administrador</p>
              </div>
              <button onClick={() => setShowNewAdminModal(false)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                <X size={24} className="text-slate-400" />
              </button>
            </div>

            <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
              {/* Personal Data */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Nombre</label>
                  <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" placeholder="Ej. Carlos" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Apellido</label>
                  <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" placeholder="Ej. Pérez" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Correo Electrónico</label>
                  <input type="email" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" placeholder="carlos@ejemplo.com" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Teléfono</label>
                  <input type="tel" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" placeholder="+54 9..." />
                </div>
              </div>

              {/* Permissions Section */}
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Permisos de Acceso (RBAC)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {menuOptions.map(option => (
                    <label key={option.id} className="flex items-center gap-3 p-4 rounded-2xl border border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer group">
                      <div className="relative flex items-center">
                        <input type="checkbox" className="peer sr-only" defaultChecked />
                        <div className="w-6 h-6 border-2 border-slate-200 rounded-lg peer-checked:bg-blue-600 peer-checked:border-blue-600 transition-all flex items-center justify-center">
                          <Check size={14} className="text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                        </div>
                      </div>
                      <span className="text-sm font-medium text-slate-700 group-hover:text-blue-600 transition-colors">{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-8 bg-slate-50 flex justify-end gap-4">
              <button onClick={() => setShowNewAdminModal(false)} className="px-6 py-3 rounded-xl font-medium text-slate-600 hover:bg-white transition-all">Cancelar</button>
              <button className="px-8 py-3 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all">Crear Acceso</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StudentRegistration({ 
  setStudentsData, 
  selectedMonth,
  categories
}: { 
  setStudentsData: React.Dispatch<React.SetStateAction<any[]>>,
  selectedMonth: string,
  categories: string[]
}) {
  const [name, setName] = useState('');
  const [dni, setDni] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [category, setCategory] = useState('');
  const [selectedMonths, setSelectedMonths] = useState<string[]>([selectedMonth]);
  const [totalPayment, setTotalPayment] = useState('');
  
  // Tutor states
  const [tutor1Name, setTutor1Name] = useState('');
  const [tutor1Email, setTutor1Email] = useState('');
  const [tutor1Phone, setTutor1Phone] = useState('');
  const [tutor2Name, setTutor2Name] = useState('');
  const [tutor2Email, setTutor2Email] = useState('');
  const [tutor2Phone, setTutor2Phone] = useState('');

  const months = ACADEMY_MONTHS;

  const toggleMonth = (monthId: string) => {
    setSelectedMonths(prev => 
      prev.includes(monthId) 
        ? prev.filter(id => id !== monthId) 
        : [...prev, monthId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !dni) {
      alert('Por favor completa los campos obligatorios (Nombre y DNI)');
      return;
    }

    const newStudent = {
      id: Date.now(),
      name,
      dni,
      category,
      status: 'active',
      birthDate: birthDate ? new Date(birthDate).toLocaleDateString() : '',
      phone: tutor1Phone,
      email: tutor1Email,
      parents: [
        { name: tutor1Name, role: 'Tutor Principal', phone: tutor1Phone, email: tutor1Email },
        ...(tutor2Name ? [{ name: tutor2Name, role: 'Tutor Secundario', phone: tutor2Phone, email: tutor2Email }] : [])
      ],
      payments: selectedMonths
    };

    setStudentsData(prev => [...prev, newStudent]);
    
    // Reset form
    setName('');
    setDni('');
    setBirthDate('');
    setCategory('');
    setSelectedMonths([selectedMonth]);
    setTotalPayment('');
    setTutor1Name('');
    setTutor1Email('');
    setTutor1Phone('');
    setTutor2Name('');
    setTutor2Email('');
    setTutor2Phone('');
    
    alert('Alumno registrado exitosamente');
  };

  useEffect(() => {
    if (birthDate) {
      const year = new Date(birthDate).getFullYear().toString();
      if (categories.includes(year)) {
        setCategory(year);
      }
    }
  }, [birthDate, categories]);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-800">Registro de Alumnos</h1>
        <p className="text-slate-500 mt-1">Ingresa los datos del nuevo integrante y su matrícula inicial</p>
      </header>

      <form className="space-y-6 pb-20" onSubmit={handleSubmit}>
        {/* Basic Info */}
        <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Users size={20} className="text-blue-500" />
            Datos del Alumno
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Nombre Completo</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                placeholder="Ej. Juan Pérez" 
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">DNI del Alumno</label>
              <input 
                type="text" 
                value={dni}
                onChange={(e) => setDni(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                placeholder="DNI" 
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Fecha de Nacimiento</label>
              <input 
                type="date" 
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Categoría</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
              >
                <option value="">Seleccionar categoría...</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Enrollment and Payment */}
        <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Calendar size={20} className="text-purple-500" />
              Matrícula y Meses de Clase
            </h2>
            <span className="text-xs font-bold text-purple-600 bg-purple-50 px-3 py-1 rounded-full">
              {selectedMonths.length} meses seleccionados
            </span>
          </div>

          <div className="space-y-4">
            <label className="text-sm font-medium text-slate-700">Selecciona los meses que el alumno está pagando por adelantado:</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {months.map((month) => (
                <button
                  key={month.id}
                  type="button"
                  onClick={() => toggleMonth(month.id)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl border transition-all text-sm font-medium ${
                    selectedMonths.includes(month.id)
                      ? 'bg-purple-600 border-purple-600 text-white shadow-md shadow-purple-200'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-purple-300'
                  }`}
                >
                  {month.name}
                  {selectedMonths.includes(month.id) && <Check size={14} />}
                </button>
              ))}
            </div>
          </div>

          <div className="h-px bg-slate-100"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                <CreditCard size={16} className="text-slate-400" />
                Monto Total Pagado (S/)
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">S/</span>
                <input 
                  type="number" 
                  value={totalPayment}
                  onChange={(e) => setTotalPayment(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 outline-none transition-all font-bold text-slate-700" 
                  placeholder="0.00" 
                />
              </div>
            </div>
            <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
              <p className="text-xs text-purple-700 font-medium leading-relaxed">
                <span className="font-bold">Nota:</span> Al guardar, el sistema marcará estos meses como pagados y el alumno aparecerá como "Activo" en los reportes correspondientes.
              </p>
            </div>
          </div>
        </div>

        {/* Tutors Info */}
        <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 space-y-6">
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <UserPlus size={20} className="text-emerald-500" />
            Datos de los Tutores (Máx 2)
          </h2>
          
          <div className="space-y-8">
            {/* Tutor 1 */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Tutor Principal</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input 
                  type="text" 
                  value={tutor1Name}
                  onChange={(e) => setTutor1Name(e.target.value)}
                  placeholder="Nombre completo" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
                <input 
                  type="email" 
                  value={tutor1Email}
                  onChange={(e) => setTutor1Email(e.target.value)}
                  placeholder="Correo electrónico" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
                <input 
                  type="tel" 
                  value={tutor1Phone}
                  onChange={(e) => setTutor1Phone(e.target.value)}
                  placeholder="Teléfono de contacto" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
              </div>
            </div>

            <div className="h-px bg-slate-100"></div>

            {/* Tutor 2 */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Tutor Secundario (Opcional)</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input 
                  type="text" 
                  value={tutor2Name}
                  onChange={(e) => setTutor2Name(e.target.value)}
                  placeholder="Nombre completo" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
                <input 
                  type="email" 
                  value={tutor2Email}
                  onChange={(e) => setTutor2Email(e.target.value)}
                  placeholder="Correo electrónico" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
                <input 
                  type="tel" 
                  value={tutor2Phone}
                  onChange={(e) => setTutor2Phone(e.target.value)}
                  placeholder="Teléfono de contacto" 
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button 
            type="button" 
            onClick={() => {
              setName('');
              setDni('');
              setBirthDate('');
              setCategory('');
              setSelectedMonths([selectedMonth]);
              setTotalPayment('');
              setTutor1Name('');
              setTutor1Email('');
              setTutor1Phone('');
              setTutor2Name('');
              setTutor2Email('');
              setTutor2Phone('');
            }}
            className="px-8 py-3 rounded-xl font-medium text-slate-600 hover:bg-white transition-all"
          >
            Cancelar
          </button>
          <button type="submit" className="px-8 py-3 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all">Guardar Alumno</button>
        </div>
      </form>
    </div>
  );
}

function TeacherManagement({ categories }: { categories: string[] }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [teacherToDelete, setTeacherToDelete] = useState<number | null>(null);
  const [editingTeacher, setEditingTeacher] = useState<any>(null);
  const [teachers, setTeachers] = useState([
    { id: 1, name: 'Carlos Rodríguez', dni: '45.678.901', birthDate: '1985-05-12', address: 'Av. Principal 123', categories: ['2012', '2014', '2016'], emoji: '👨‍🏫', phone: '+54 9 11 2233-4455' },
    { id: 2, name: 'Elena Martínez', dni: '38.901.234', birthDate: '1990-08-24', address: 'Calle Roble 456', categories: ['2018', '2017'], emoji: '👩‍🏫', phone: '+54 9 11 5566-7788' },
    { id: 3, name: 'Javier López', dni: '42.345.678', birthDate: '1988-11-03', address: 'Pje. Los Pinos 78', categories: ['2013', '2015'], emoji: '⚽', phone: '+54 9 11 9900-1122' },
  ]);

  const handleEdit = (teacher: any) => {
    setEditingTeacher(teacher);
    setShowModal(true);
  };

  const handleAdd = () => {
    setEditingTeacher(null);
    setShowModal(true);
  };

  const handleDelete = (id: number) => {
    setTeacherToDelete(id);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = () => {
    if (teacherToDelete !== null) {
      setTeachers(prev => prev.filter(t => t.id !== teacherToDelete));
      setShowDeleteConfirm(false);
      setTeacherToDelete(null);
    }
  };

  const handleSave = (data: any) => {
    if (editingTeacher) {
      setTeachers(prev => prev.map(t => t.id === editingTeacher.id ? { ...data, id: t.id } : t));
    } else {
      setTeachers(prev => [...prev, { ...data, id: Math.max(0, ...prev.map(t => t.id)) + 1 }]);
    }
    setShowModal(false);
  };

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.dni.includes(searchTerm)
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Gestión de Profesores</h1>
          <p className="text-slate-500 mt-1">Administra el staff técnico de la academia</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:flex-none">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar profesor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm w-full md:w-64 shadow-sm"
            />
          </div>
          <button 
            onClick={handleAdd}
            className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 whitespace-nowrap"
          >
            <UserPlus size={20} />
            Nuevo Profesor
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTeachers.map(teacher => (
          <div key={teacher.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-2xl border border-slate-100">
                  {teacher.emoji}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">{teacher.name}</h3>
                  <p className="text-xs text-slate-500">DNI: {teacher.dni}</p>
                </div>
              </div>
              <button 
                onClick={() => handleEdit(teacher)}
                className="text-blue-500 hover:bg-blue-50 p-2 rounded-lg transition-colors"
              >
                <SettingsIcon size={18} />
              </button>
            </div>

            <div className="space-y-3 text-[13px]">
              <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 shadow-sm">
                  <Calendar size={14} />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Fecha de Nacimiento</p>
                  <p className="text-slate-700 font-medium">{teacher.birthDate}</p>
                </div>
              </div>
              <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-blue-500 shadow-sm">
                  <Phone size={14} />
                </div>
                <div>
                  <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Teléfono de Contacto</p>
                  <p className="text-slate-700 font-medium">{teacher.phone}</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Categorías Asignadas</p>
              <div className="flex flex-wrap gap-2">
                {teacher.categories.map(cat => (
                  <span key={cat} className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-xs font-bold border border-blue-100/50">
                    {cat}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
              <span className="flex items-center gap-2 text-xs text-emerald-600 font-bold">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                Activo
              </span>
              <button 
                onClick={() => handleDelete(teacher.id)}
                className="text-xs font-bold text-slate-400 hover:text-rose-500 transition-colors"
              >
                Dar de Baja
              </button>
            </div>
          </div>
        ))}
      </div>

      <TeacherModal 
        isOpen={showModal} 
        onClose={() => setShowModal(false)} 
        teacher={editingTeacher} 
        onSave={handleSave}
        categories={categories}
      />

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] w-full max-w-md shadow-2xl p-8 space-y-6 animate-in fade-in zoom-in duration-200">
            <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto">
              <AlertCircle size={32} />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-xl font-bold text-slate-800">¿Estás seguro?</h3>
              <p className="text-slate-500">Esta acción dará de baja al profesor de forma permanente.</p>
            </div>
            <div className="flex gap-4">
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-3 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-all"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 py-3 bg-rose-500 text-white font-bold rounded-xl hover:bg-rose-600 shadow-lg shadow-rose-500/20 transition-all"
              >
                Dar de Baja
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TeacherModal({ isOpen, onClose, teacher, onSave, categories }: { isOpen: boolean, onClose: () => void, teacher?: any, onSave: (data: any) => void, categories: string[] }) {
  const [formData, setFormData] = useState({
    name: '',
    dni: '',
    birthDate: '',
    phone: '',
    address: '',
    categories: [] as string[],
    emoji: '👨‍🏫'
  });

  useEffect(() => {
    if (teacher) {
      setFormData({
        ...teacher,
      });
    } else {
      setFormData({
        name: '',
        dni: '',
        birthDate: '',
        phone: '',
        address: '',
        categories: [],
        emoji: '👨‍🏫'
      });
    }
  }, [teacher, isOpen]);

  const toggleCategory = (cat: string) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.includes(cat)
        ? prev.categories.filter(c => c !== cat)
        : [...prev.categories, cat]
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-8 bg-blue-600 text-white relative">
          <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X size={20} />
          </button>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-2xl">
              {formData.emoji}
            </div>
            <div>
              <h3 className="text-xl font-bold">{teacher ? 'Editar Profesor' : 'Nuevo Profesor'}</h3>
              <p className="text-blue-100 text-sm">Completa los datos del staff técnico</p>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Nombre Completo</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                placeholder="Ej. Carlos Rodríguez"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">DNI</label>
              <input 
                type="text" 
                value={formData.dni}
                onChange={(e) => setFormData(prev => ({ ...prev, dni: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                placeholder="DNI"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Fecha de Nacimiento</label>
              <input 
                type="date" 
                value={formData.birthDate}
                onChange={(e) => setFormData(prev => ({ ...prev, birthDate: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Teléfono</label>
              <input 
                type="tel" 
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                placeholder="+54 9 11 ..."
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-bold text-slate-700">Dirección</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                  placeholder="Calle, Número, Ciudad"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-sm font-bold text-slate-700">Categorías Asignadas</label>
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => toggleCategory(cat)}
                  className={`px-4 py-2 rounded-xl border text-sm font-bold transition-all ${
                    formData.categories.includes(cat)
                      ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-200'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-blue-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-8 bg-slate-50 flex gap-4">
          <button 
            onClick={onClose}
            className="flex-1 py-4 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-100 transition-all"
          >
            Cancelar
          </button>
          <button 
            onClick={() => onSave(formData)}
            className="flex-1 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
          >
            {teacher ? 'Guardar Cambios' : 'Registrar Profesor'}
          </button>
        </div>
      </div>
    </div>
  );
}

function EvaluationModal({ isOpen, onClose, onSave, studentName }: any) {
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    performance: {
      technical: 75,
      physical: 75,
      tactical: 75,
      psychological: 75
    },
    biometrics: {
      weight: 0,
      height: 0,
      imc: 0
    },
    notes: ''
  });

  useEffect(() => {
    const weight = Number(formData.biometrics.weight);
    const height = Number(formData.biometrics.height);
    if (weight > 0 && height > 0) {
      const imc = weight / (height * height);
      setFormData(prev => ({
        ...prev,
        biometrics: { ...prev.biometrics, imc }
      }));
    }
  }, [formData.biometrics.weight, formData.biometrics.height]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-8 bg-blue-600 text-white relative">
          <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X size={20} />
          </button>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center text-2xl">
              📊
            </div>
            <div>
              <h3 className="text-xl font-bold">Nueva Evaluación</h3>
              <p className="text-blue-100 text-sm">Evaluando a {studentName}</p>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Fecha de Evaluación</label>
              <input 
                type="date" 
                value={formData.date}
                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
              />
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Rendimiento (0-100)</h4>
            <div className="grid grid-cols-2 gap-6">
              {Object.entries(formData.performance).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 capitalize">{key === 'technical' ? 'Técnico' : key === 'physical' ? 'Físico' : key === 'tactical' ? 'Táctico' : 'Psicológico'}</label>
                  <div className="flex items-center gap-4">
                    <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      value={value}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        performance: { ...prev.performance, [key]: Number(e.target.value) }
                      }))}
                      className="flex-1 h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                    <span className="text-sm font-bold text-slate-700 w-8">{value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider">Biometría</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500">Peso (kg)</label>
                <input 
                  type="number" 
                  step="0.1"
                  value={formData.biometrics.weight || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    biometrics: { ...prev.biometrics, weight: Number(e.target.value) }
                  }))}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                  placeholder="0.0"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500">Talla (m)</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={formData.biometrics.height || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    biometrics: { ...prev.biometrics, height: Number(e.target.value) }
                  }))}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all" 
                  placeholder="0.00"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500">IMC</label>
                <div className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-100 text-slate-600 font-bold">
                  {formData.biometrics.imc.toFixed(1)}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-700">Observaciones y Notas</label>
            <textarea 
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all h-32 resize-none"
              placeholder="Escribe aquí los comentarios sobre el desempeño del alumno..."
            />
          </div>
        </div>

        <div className="p-8 bg-slate-50 flex gap-4">
          <button 
            onClick={onClose}
            className="flex-1 py-4 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-100 transition-all"
          >
            Cancelar
          </button>
          <button 
            onClick={() => onSave(formData)}
            className="flex-1 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 shadow-lg shadow-blue-500/20 transition-all"
          >
            Guardar Evaluación
          </button>
        </div>
      </div>
    </div>
  );
}
