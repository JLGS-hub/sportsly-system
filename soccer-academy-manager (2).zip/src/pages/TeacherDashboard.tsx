import React, { useState, useEffect } from 'react';
import { Search, Filter, Users, LogOut, TrendingUp, Menu, X, Calendar, Clock, History, ChevronLeft, ChevronRight, ArrowLeft, Shield, Camera, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';

// Reusing the same mock data structure for consistency
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1;
const currentMonthStr = `${currentYear}-${currentMonth.toString().padStart(2, '0')}`;

const getAcademyMonths = () => {
  const months = [];
  const date = new Date();
  date.setMonth(date.getMonth() - 6);
  for (let i = 0; i < 13; i++) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const id = `${year}-${month.toString().padStart(2, '0')}`;
    const name = date.toLocaleString('es-ES', { month: 'long' });
    const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);
    months.push({ id, name: `${capitalizedName} ${year}` });
    date.setMonth(date.getMonth() + 1);
  }
  return months;
};

const ACADEMY_MONTHS = getAcademyMonths();

export default function TeacherDashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('my-students');
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [showEvaluationModal, setShowEvaluationModal] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(currentMonthStr);
  
  // Mock data (in a real app, this would come from Supabase filtered by teacher_id)
  const [studentsData, setStudentsData] = useState([
    { 
      id: 1,
      name: 'Mateo García', 
      dni: '48.123.456', 
      category: '2012',
      status: 'active',
      birthDate: '15/03/2012',
      phone: '+54 9 11 1234-5678',
      email: 'mateo.garcia@email.com',
      photo: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=200&auto=format&fit=crop',
      parents: [
        { name: 'Roberto García', role: 'Padre', phone: '+54 9 11 8765-4321', email: 'roberto.g@email.com' }
      ],
      payments: [currentMonthStr],
      attendance: [1, 3, 5, 8, 10, 12, 15],
      biometrics: { weight: 42, height: 1.55, imc: 17.5 },
      evaluations: [
        { date: '2026-01-15', technical: 70, physical: 65, tactical: 60, psychological: 80, weight: 41, height: 1.54, notes: 'Buen inicio de año.' },
        { date: '2026-02-15', technical: 75, physical: 70, tactical: 65, psychological: 85, weight: 41.5, height: 1.54, notes: 'Mejora en resistencia.' },
        { date: '2026-03-15', technical: 85, physical: 70, tactical: 75, psychological: 90, weight: 42, height: 1.55, notes: 'Excelente progreso técnico.' },
      ],
      performance: [
        { name: 'Ene', valor: 68 },
        { name: 'Feb', valor: 72 },
        { name: 'Mar', valor: 80 },
      ],
      skills: [
        { subject: 'Técnico', A: 85, fullMark: 100 },
        { subject: 'Físico', A: 70, fullMark: 100 },
        { subject: 'Táctico', A: 75, fullMark: 100 },
        { subject: 'Psicológico', A: 90, fullMark: 100 },
        { subject: 'Asistencia', A: 85, fullMark: 100 },
        { subject: 'Biométrico', A: 65, fullMark: 100 },
      ]
    }
  ]);

  const academyName = localStorage.getItem('academyName') || 'Sportly Academy';
  const logo = localStorage.getItem('logo') || '⚽';

  return (
    <div className="min-h-screen flex font-sans bg-slate-50/50">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform lg:translate-x-0 lg:static ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 border-b border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-white shadow-lg">
            <span className="text-xl">{logo}</span>
          </div>
          <span className="font-bold text-slate-800 truncate">{academyName}</span>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => { setActiveTab('my-students'); setIsSidebarOpen(false); setSelectedStudentId(null); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'my-students' && !selectedStudentId ? 'bg-emerald-50 text-emerald-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Users size={20} />
            <span className="font-medium">Mis Alumnos</span>
          </button>
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3 px-4 py-3 mb-4">
            <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 font-bold">PR</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-800 truncate">Prof. Ricardo</p>
              <p className="text-[10px] text-slate-500 font-medium">Docente</p>
            </div>
          </div>
          <Link to="/login" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50 transition-colors">
            <LogOut size={20} />
            <span className="font-medium">Cerrar Sesión</span>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="lg:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-30">
          <span className="font-bold text-slate-800">{academyName}</span>
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-slate-100 rounded-lg">
            <Menu size={24} className="text-slate-600" />
          </button>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {selectedStudentId ? (
            <TeacherStudentProfile 
              student={studentsData.find(s => s.id === selectedStudentId)}
              onBack={() => setSelectedStudentId(null)}
              onAddEvaluation={() => setShowEvaluationModal(true)}
            />
          ) : (
            <div className="space-y-8">
              <header>
                <h1 className="text-3xl font-bold text-slate-800">Mis Alumnos Asignados</h1>
                <p className="text-slate-500 mt-1">Gestiona el rendimiento de tus deportistas</p>
              </header>

              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-xs uppercase tracking-wider">
                      <th className="px-6 py-4 font-semibold">Alumno</th>
                      <th className="px-6 py-4 font-semibold">Categoría</th>
                      <th className="px-6 py-4 font-semibold">Última Eval.</th>
                      <th className="px-6 py-4 font-semibold text-right">Acción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {studentsData.map((student) => (
                      <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl overflow-hidden bg-slate-100">
                              <img src={student.photo} alt="" className="w-full h-full object-cover" />
                            </div>
                            <span className="font-medium text-slate-700">{student.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-slate-500">{student.category}</td>
                        <td className="px-6 py-4 text-slate-500">
                          {student.evaluations.length > 0 ? new Date(student.evaluations[student.evaluations.length-1].date).toLocaleDateString() : 'Pendiente'}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button 
                            onClick={() => setSelectedStudentId(student.id)}
                            className="text-emerald-600 hover:text-emerald-700 font-bold text-sm"
                          >
                            Evaluar Rendimiento
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {showEvaluationModal && selectedStudentId && (
        <TeacherEvaluationModal 
          isOpen={showEvaluationModal}
          onClose={() => setShowEvaluationModal(false)}
          studentName={studentsData.find(s => s.id === selectedStudentId)?.name || ''}
          onSave={(evaluation: any) => {
            setStudentsData(prev => prev.map(s => {
              if (s.id === selectedStudentId) {
                return { ...s, evaluations: [...s.evaluations, evaluation] };
              }
              return s;
            }));
            setShowEvaluationModal(false);
          }}
        />
      )}
    </div>
  );
}

function TeacherStudentProfile({ student, onBack, onAddEvaluation }: any) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-50 rounded-2xl transition-all text-slate-600 font-bold text-sm shadow-sm border border-slate-100">
            <ArrowLeft size={18} />
            Volver
          </button>
          <h1 className="text-3xl font-bold text-slate-800">{student.name}</h1>
        </div>
        <button 
          onClick={onAddEvaluation}
          className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-2xl font-bold text-sm shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 transition-all"
        >
          <TrendingUp size={18} />
          Nueva Evaluación
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="space-y-8">
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 flex flex-col items-center text-center space-y-4">
            <div className="w-32 h-32 rounded-[40px] overflow-hidden border-4 border-slate-50 shadow-xl">
              <img src={student.photo} alt={student.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{student.name}</h2>
              <p className="text-emerald-600 font-bold text-sm uppercase tracking-wider">Categoría {student.category}</p>
            </div>
          </div>
          
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Shield size={20} className="text-emerald-500" />
              Biometría Actual
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-center">
                <p className="text-[10px] font-bold text-emerald-600 uppercase">Peso</p>
                <p className="text-lg font-bold text-slate-800">{student.biometrics.weight} kg</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 text-center">
                <p className="text-[10px] font-bold text-blue-600 uppercase">Talla</p>
                <p className="text-lg font-bold text-slate-800">{student.biometrics.height} m</p>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <TrendingUp size={20} className="text-emerald-500" />
              Rendimiento Histórico
            </h3>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={student.performance}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} domain={[0, 100]} />
                  <Tooltip />
                  <Area type="monotone" dataKey="valor" stroke="#10b981" fill="#10b981" fillOpacity={0.1} strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <History size={20} className="text-emerald-500" />
              Histórico de Evaluaciones
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b border-slate-100">
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fecha</th>
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Rendimiento</th>
                    <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Observaciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[...student.evaluations].reverse().slice((currentPage-1)*itemsPerPage, currentPage*itemsPerPage).map((evalItem: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-4 text-xs font-bold text-slate-700">{new Date(evalItem.date).toLocaleDateString()}</td>
                      <td className="py-4">
                        <div className="flex gap-1">
                          <span className="text-[9px] px-1.5 py-0.5 bg-emerald-50 text-emerald-600 rounded-md font-bold">T: {evalItem.technical}</span>
                          <span className="text-[9px] px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md font-bold">F: {evalItem.physical}</span>
                        </div>
                      </td>
                      <td className="py-4 text-xs text-slate-600 italic">{evalItem.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {student.evaluations.length > itemsPerPage && (
              <div className="flex items-center justify-center gap-4 pt-4">
                <button onClick={() => setCurrentPage(p => Math.max(1, p-1))} disabled={currentPage === 1} className="p-2 border rounded-xl disabled:opacity-30"><ChevronLeft size={20}/></button>
                <span className="text-xs font-bold">Página {currentPage}</span>
                <button onClick={() => setCurrentPage(p => p+1)} disabled={currentPage*itemsPerPage >= student.evaluations.length} className="p-2 border rounded-xl disabled:opacity-30"><ChevronRight size={20}/></button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function TeacherEvaluationModal({ isOpen, onClose, onSave, studentName }: any) {
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    technical: 70, physical: 70, tactical: 70, psychological: 70,
    weight: 0, height: 0, notes: ''
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-[40px] w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Evaluación de Rendimiento</h3>
            <p className="text-emerald-600 text-sm font-medium">{studentName}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-emerald-100 rounded-xl transition-colors"><X size={24} className="text-emerald-400" /></button>
        </div>
        <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Fecha de Evaluación</label>
              <input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 outline-none" />
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-slate-800">Rendimiento (0-100)</h4>
            <div className="grid grid-cols-2 gap-6">
              {['technical', 'physical', 'tactical', 'psychological'].map(skill => (
                <div key={skill}>
                  <div className="flex justify-between mb-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">{skill === 'technical' ? 'Técnico' : skill === 'physical' ? 'Físico' : skill === 'tactical' ? 'Táctico' : 'Psicológico'}</label>
                    <span className="text-xs font-bold text-emerald-600">{(formData as any)[skill]}</span>
                  </div>
                  <input type="range" min="0" max="100" value={(formData as any)[skill]} onChange={e => setFormData({...formData, [skill]: parseInt(e.target.value)})} className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-slate-800">Biometría</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Peso (kg)</label>
                <input type="number" step="0.1" value={formData.weight} onChange={e => setFormData({...formData, weight: parseFloat(e.target.value)})} className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Talla (m)</label>
                <input type="number" step="0.01" value={formData.height} onChange={e => setFormData({...formData, height: parseFloat(e.target.value)})} className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none" />
              </div>
            </div>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Observaciones y Notas</label>
            <textarea rows={3} value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-slate-200 outline-none resize-none" placeholder="Escribe aquí el feedback para el alumno..." />
          </div>
        </div>
        <div className="p-8 bg-slate-50 flex justify-end gap-3">
          <button onClick={onClose} className="px-6 py-3 text-slate-500 font-bold hover:bg-slate-100 rounded-xl transition-all">Cancelar</button>
          <button onClick={() => onSave(formData)} className="px-10 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20">Guardar Evaluación</button>
        </div>
      </div>
    </div>
  );
}
