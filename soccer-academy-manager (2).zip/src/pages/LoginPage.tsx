import { Link } from 'react-router-dom';

export default function LoginPage() {
  const getSafeStorage = (key: string, defaultValue: string) => {
    try {
      return localStorage.getItem(key) || defaultValue;
    } catch (e) {
      console.error('Error accessing localStorage:', e);
      return defaultValue;
    }
  };

  const loginLogo = getSafeStorage('loginLogo', '⚽');
  const loginName = getSafeStorage('loginName', 'Bienvenido');
  const loginBgImage = getSafeStorage('loginBgImage', 'https://images.unsplash.com/photo-1502691876148-a84978e59af8?q=80&w=2070&auto=format&fit=crop');

  return (
    <div 
      className="min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat p-4 font-sans relative"
      style={{ 
        backgroundImage: loginBgImage === 'none' ? 'none' : `url('${loginBgImage}')`,
        backgroundColor: loginBgImage === 'none' ? '#f8fafc' : 'transparent'
      }}
    >
      {/* Dark overlay to match the deep blue tones of the provided image */}
      <div className="absolute inset-0 bg-blue-950/30"></div>
      <div className="absolute inset-0 bg-black/20"></div>

      <div className="max-w-md w-full bg-white rounded-[32px] shadow-2xl p-10 relative z-10">
        
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center overflow-hidden shrink-0">
              {loginLogo.startsWith('data:image') || loginLogo.startsWith('http') ? (
                <img src={loginLogo} alt="Academy Logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-2xl">{loginLogo}</span>
              )}
            </div>
            <h1 className="text-2xl font-bold text-slate-800 leading-tight">{loginName}</h1>
          </div>
          <p className="text-slate-500 text-sm">Ingresa a tu portal de la academia</p>
        </div>

        <div className="space-y-4">
          <Link 
            to="/admin/dashboard"
            className="flex items-center justify-between w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-4 px-6 rounded-2xl transition-all shadow-sm group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <span className="text-xl">🛡️</span>
              </div>
              <div className="text-left">
                <span className="block text-sm font-bold">Administración</span>
                <span className="block text-xs text-blue-100 font-normal">Acceso total al sistema</span>
              </div>
            </div>
            <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </Link>

          <Link 
            to="/teacher/dashboard"
            className="flex items-center justify-between w-full bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-4 px-6 rounded-2xl transition-all shadow-sm group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <span className="text-xl">📋</span>
              </div>
              <div className="text-left">
                <span className="block text-sm font-bold">Profesor</span>
                <span className="block text-xs text-emerald-100 font-normal">Gestión de alumnos asignados</span>
              </div>
            </div>
            <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </Link>

          <Link 
            to="/student/dashboard"
            className="flex items-center justify-between w-full bg-amber-500 hover:bg-amber-600 text-white font-medium py-4 px-6 rounded-2xl transition-all shadow-sm group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <span className="text-xl">⚽</span>
              </div>
              <div className="text-left">
                <span className="block text-sm font-bold">Alumno / Tutor</span>
                <span className="block text-xs text-amber-100 font-normal">Ver ficha y rendimiento</span>
              </div>
            </div>
            <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
