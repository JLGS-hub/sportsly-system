import React, { useState } from 'react';
import { LogOut, Calendar, Clock, History, ChevronLeft, ChevronRight, Shield, TrendingUp, User, GraduationCap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';

export default function StudentDashboard() {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Mock data for the logged-in student (Mateo García)
  const student = {
    name: 'Mateo García',
    category: '2012',
    photo: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=200&auto=format&fit=crop',
    biometrics: { weight: 42, height: 1.55, imc: 17.5 },
    performance: [
      { name: 'Ene', valor: 68 },
      { name: 'Feb', valor: 72 },
      { name: 'Mar', valor: 80 },
    ],
    skills: [
      { subject: 'Técnico', A: 85, fullMark: 100 },
      { subject: 'Físico', A: 70, fullMark: 100 },
      { subject: 'Táctico', A: 75, fullMark: 100 },
      { subject: 'Psicológico', A: 90, fullMark: 100 },
      { subject: 'Asistencia', A: 85, fullMark: 100 },
      { subject: 'Biométrico', A: 65, fullMark: 100 },
    ],
    evaluations: [
      { date: '2026-01-15', technical: 70, physical: 65, tactical: 60, psychological: 80, weight: 41, height: 1.54, notes: 'Buen inicio de año, enfocado en fundamentos.' },
      { date: '2026-02-15', technical: 75, physical: 70, tactical: 65, psychological: 85, weight: 41.5, height: 1.54, notes: 'Mejora notable en resistencia.' },
      { date: '2026-03-15', technical: 85, physical: 70, tactical: 75, psychological: 90, weight: 42, height: 1.55, notes: 'Excelente progreso técnico este mes.' },
    ],
    schedules: [
      { day: 'Lunes', time: '17:00 - 18:30' },
      { day: 'Miércoles', time: '17:00 - 18:30' },
      { day: 'Viernes', time: '17:00 - 18:30' },
    ]
  };

  const academyName = localStorage.getItem('academyName') || 'Sportly Academy';
  const logo = localStorage.getItem('logo') || '⚽';

  return (
    <div className="min-h-screen bg-slate-50/50 font-sans">
      {/* Simple Header for Students */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center text-white shadow-lg">
              <span className="text-xl">{logo}</span>
            </div>
            <span className="font-bold text-slate-800 text-lg hidden sm:block">{academyName}</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 px-4 py-2 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-200">
                <img src={student.photo} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="hidden sm:block">
                <p className="text-xs font-bold text-slate-800">{student.name}</p>
                <p className="text-[10px] text-amber-600 font-bold uppercase">Alumno</p>
              </div>
            </div>
            <Link to="/login" className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors">
              <LogOut size={20} />
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
        {/* Welcome Section */}
        <section className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-[40px] p-8 md:p-12 text-white shadow-2xl shadow-amber-500/20 relative overflow-hidden">
          <div className="relative z-10 space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold">¡Hola, {student.name.split(' ')[0]}! 👋</h1>
            <p className="text-amber-50 max-w-md">Aquí puedes ver tu progreso, horarios y evaluaciones de rendimiento.</p>
            <div className="flex flex-wrap gap-3 pt-2">
              <span className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-2xl text-sm font-bold border border-white/30">
                Categoría {student.category}
              </span>
              <span className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-2xl text-sm font-bold border border-white/30 flex items-center gap-2">
                <Shield size={16} /> Activo
              </span>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-black/10 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column: Schedules & Biometrics */}
          <div className="space-y-8">
            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Calendar size={20} className="text-amber-500" />
                Mis Horarios
              </h3>
              <div className="space-y-3">
                {student.schedules.map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <span className="text-sm font-bold text-slate-700">{s.day}</span>
                    <span className="flex items-center gap-2 text-xs font-bold text-amber-600 bg-amber-50 px-3 py-1.5 rounded-xl">
                      <Clock size={14} />
                      {s.time}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Shield size={20} className="text-blue-500" />
                Mi Biometría
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-5 bg-blue-50 rounded-3xl border border-blue-100 text-center">
                  <p className="text-[10px] font-bold text-blue-600 uppercase mb-1">Peso</p>
                  <p className="text-2xl font-bold text-slate-800">{student.biometrics.weight} <span className="text-xs font-medium">kg</span></p>
                </div>
                <div className="p-5 bg-emerald-50 rounded-3xl border border-emerald-100 text-center">
                  <p className="text-[10px] font-bold text-emerald-600 uppercase mb-1">Talla</p>
                  <p className="text-2xl font-bold text-slate-800">{student.biometrics.height} <span className="text-xs font-medium">m</span></p>
                </div>
              </div>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-center">
                <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Índice de Masa Corporal (IMC)</p>
                <p className="text-xl font-bold text-slate-700">{student.biometrics.imc}</p>
              </div>
            </div>
          </div>

          {/* Right Column: Performance Charts */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp size={20} className="text-amber-500" />
                Mi Curva de Rendimiento
              </h3>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={student.performance}>
                    <defs>
                      <linearGradient id="colorValor" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} domain={[0, 100]} />
                    <Tooltip contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)'}} />
                    <Area type="monotone" dataKey="valor" stroke="#f59e0b" strokeWidth={4} fillOpacity={1} fill="url(#colorValor)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Shield size={20} className="text-purple-500" />
                  Mis Habilidades
                </h3>
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={student.skills}>
                      <PolarGrid stroke="#f1f5f9" />
                      <PolarAngleAxis dataKey="subject" tick={{fill: '#64748b', fontSize: 10, fontWeight: 'bold'}} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                      <Radar name="Rendimiento" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.5} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <GraduationCap size={20} className="text-emerald-500" />
                  Último Feedback
                </h3>
                <div className="p-6 bg-emerald-50 rounded-[32px] border border-emerald-100 relative">
                  <span className="absolute -top-3 -left-3 text-4xl opacity-20">"</span>
                  <p className="text-sm text-emerald-800 italic leading-relaxed">
                    {student.evaluations[student.evaluations.length - 1].notes}
                  </p>
                  <div className="mt-4 flex items-center gap-3">
                    <div className="w-8 h-8 bg-emerald-200 rounded-full flex items-center justify-center text-xs">👨‍🏫</div>
                    <p className="text-[10px] font-bold text-emerald-700">Prof. Ricardo • {new Date(student.evaluations[student.evaluations.length - 1].date).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Evaluation History (Read-only) */}
            <div className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100 space-y-6">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <History size={20} className="text-blue-500" />
                Mi Histórico de Evaluaciones
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-slate-100">
                      <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Fecha</th>
                      <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Rendimiento</th>
                      <th className="pb-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Observaciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {[...student.evaluations].reverse().slice((currentPage-1)*itemsPerPage, currentPage*itemsPerPage).map((evalItem: any, idx: number) => (
                      <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 text-xs font-bold text-slate-700">{new Date(evalItem.date).toLocaleDateString()}</td>
                        <td className="py-4">
                          <div className="flex gap-1">
                            <span className="text-[9px] px-1.5 py-0.5 bg-emerald-50 text-emerald-600 rounded-md font-bold">Téc: {evalItem.technical}</span>
                            <span className="text-[9px] px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md font-bold">Fís: {evalItem.physical}</span>
                          </div>
                        </td>
                        <td className="py-4 text-xs text-slate-600 italic">{evalItem.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {student.evaluations.length > itemsPerPage && (
                <div className="flex items-center justify-center gap-4 pt-4">
                  <button onClick={() => setCurrentPage(p => Math.max(1, p-1))} disabled={currentPage === 1} className="p-2 border rounded-xl disabled:opacity-30"><ChevronLeft size={20}/></button>
                  <span className="text-xs font-bold">Página {currentPage}</span>
                  <button onClick={() => setCurrentPage(p => p+1)} disabled={currentPage*itemsPerPage >= student.evaluations.length} className="p-2 border rounded-xl disabled:opacity-30"><ChevronRight size={20}/></button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
