-- SQL Schema for Soccer Academy Manager

-- 1. Create a table for Students
CREATE TABLE IF NOT EXISTS students (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  student_code TEXT UNIQUE NOT NULL, -- Unique code for each student
  full_name TEXT NOT NULL,
  dni TEXT UNIQUE NOT NULL,
  birth_date DATE NOT NULL,
  category TEXT NOT NULL, -- Calculated based on birth year
  status TEXT DEFAULT 'active', -- active, inactive
  
  -- Tutor 1
  tutor1_name TEXT NOT NULL,
  tutor1_dni TEXT,
  tutor1_phone TEXT NOT NULL,
  
  -- Tutor 2 (Optional)
  tutor2_name TEXT,
  tutor2_dni TEXT,
  tutor2_phone TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create a table for Teachers
CREATE TABLE IF NOT EXISTS teachers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  birth_date DATE NOT NULL,
  dni TEXT UNIQUE NOT NULL,
  address TEXT NOT NULL,
  assigned_categories TEXT[], -- Array of categories (e.g., ['2012', '2014'])
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Create a table for Payments
CREATE TABLE IF NOT EXISTS payments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID REFERENCES students(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  month_paid TEXT NOT NULL, -- e.g., 'Octubre 2023'
  status TEXT DEFAULT 'pending', -- paid, pending, late
  payment_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Create policies (Example: Allow authenticated users to read/write)
CREATE POLICY "Allow authenticated users to read students" ON students FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to insert students" ON students FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to update students" ON students FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to read teachers" ON teachers FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to insert teachers" ON teachers FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to update teachers" ON teachers FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to read payments" ON payments FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to insert payments" ON payments FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated users to update payments" ON payments FOR UPDATE USING (auth.role() = 'authenticated');
